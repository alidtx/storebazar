```bash
git clone git@bitbucket.org:sslengineering/b71-ssg.git
cd b71-ssg
yarn install
#Update corresponding .env file if needed
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

