import { useEffect } from 'react'
import { Provider } from "react-redux";
import withRedux from "next-redux-wrapper";
import { PersistGate } from 'redux-persist/integration/react';
import { ApolloProvider } from "@apollo/client";
import { useApollo, initializeApollo } from "../server/apollo";

import Layout from '../components/layout';
import Footer from "../components/common/footer";

import makeStore from "../store";

import { CMS_CONTENT_QUERY } from '../server/queries';

import "../public/sass/style.scss";
import LoadingPlaceholder from '../components/partials/loading-placeholder';
import * as gtag from '../lib/gtag';
import Script from 'next/script';
import { useRouter } from 'next/router'


function MyApp({ Component, pageProps, store, FooterContent }) {
  const apolloClient = useApollo(pageProps?.initialApolloState);

  const router = useRouter()
  useEffect(() => {
    const handleRouteChange = (url) => {
      gtag.pageview(url)
    }
    router.events.on('routeChangeComplete', handleRouteChange)
    router.events.on('hashChangeComplete', handleRouteChange)
    return () => {
      router.events.off('routeChangeComplete', handleRouteChange)
      router.events.off('hashChangeComplete', handleRouteChange)
    }
  }, [router.events]);

  return (
    <ApolloProvider client={apolloClient}>
      {/* Global Site Tag (gtag.js) - Google Analytics */}
      <Script
        strategy="afterInteractive"
        src={`https://www.googletagmanager.com/gtag/js?id=${gtag.GA_TRACKING_ID}`}
      />
      <Script
        id="gtag-init"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${gtag.GA_TRACKING_ID}', {
              page_path: window.location.pathname,
            });
          `,
        }}
      />
      <Provider store={store}>
        <PersistGate
          persistor={store?.__persistor}
          loading={null
            // <div className="loading-overlay">
            //     <div className="bounce-loader">
            //         <div className="bounce1"></div>
            //         <div className="bounce2"></div>
            //         <div className="bounce3"></div>
            //         <div className="bounce4"></div>
            //     </div>
            // </div>
            // <LoadingPlaceholder />
          }
        >
          <Layout>
            <Component {...pageProps} />
            <Footer FooterContent={FooterContent?.data} />
          </Layout>
        </PersistGate>
      </Provider>
    </ApolloProvider>
  );
}

export async function getStaticProps() {
  const apolloClient = initializeApollo();

  await apolloClient.query({
    query: CMS_CONTENT_QUERY,
  });

  console.log("res", await res.json());
  let content = await results.json();

  return {
    props: {
      initialApolloState: apolloClient.cache.extract()
    },
    revalidate: 1,
  };
}

export default withRedux(makeStore)(MyApp);
