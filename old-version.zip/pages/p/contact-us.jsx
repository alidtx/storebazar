import React, { useState } from "react";
import Head from "next/head";
import Reveal from "react-awesome-reveal";
// import { LazyLoadImage } from "react-lazy-load-image-component";
import GoogleMapReact from "google-map-react";
import ALink from "../../components/features/custom-link";
import { fadeIn } from "../../utils/data/keyframes";
import {GET_ALL_CONFIGURATION} from '../../server/queries';
import { useMutation, useQuery } from '@apollo/client';
import {SEND_CONTACT_FORM_DATA} from '../../server/queries';
import { toast } from 'react-toastify';


const AnyReactComponent = ({ text }) => <div>{text}</div>;

function ContactUs() {
    // States
    const [formdata, setFormdata] = useState(null);
    const [contactsConfigData, setContactsConfigData] = useState(null);


    const allConfigs = useQuery(GET_ALL_CONFIGURATION, {
        variables: {
            first: 100,
            page: 1,
        },
        fetchPolicy: "no-cache",
        onCompleted(data) {
            if(data?.configs?.data) {
                let fieldsValues = {};
                data?.configs?.data.forEach((item, index) => {
                    if (
                        item.key === "CONTACT_EMAIL" ||
                        item.key === "GOOGLE_MAPS_API"
                    ) {
                        fieldsValues[item.key] = item.value;
                    }
                });

                setContactsConfigData(fieldsValues);
            }
        },
        onError(error) {
            console.log("ERROR fetching all configs: ", error);
        }
    });

    const [onSubmitFormData] = useMutation(SEND_CONTACT_FORM_DATA);

    const onSubmitForm = async(event) => {
        event.preventDefault();
        if (formdata && formdata.comment && formdata.name && formdata.email) {
            try {
                const { data } = await onSubmitFormData({
                    variables: {
                        text: formdata.comment,
                        name: formdata.name,
                        email: formdata.email,
                    }
                });

                if(data && data.sendContactFormData) {
                    toast.success("Form Submitted Successfully");
                    setFormdata(null);
                }
                else {
                    toast.error("ERROR: Unable to submit form");
                }
            }
            catch(error) {
                toast.error(
                    `${
                        error?.graphQLErrors && error?.graphQLErrors[0]?.message
                            ? error?.graphQLErrors[0]?.message
                            : "Something went wrong!"
                    }`
                );
            }
        } else {
            toast.error("ERROR: Please add all required fields");
        }
    };

    const onChangeInput = (event) => {
        const value = event.target.value;
        setFormdata({
            ...formdata,
            [event.target.name]: value,
        });
    };

    return (
        <main className="main contact-us">
            <Head>
                <title>জমিলার দোকান - যোগাযোগ করুন</title>
            </Head>

            <h1 className="d-none">B71 Ecommerce | Contact Us</h1>

            <nav className="breadcrumb-nav">
                <div className="container">
                    <ul className="breadcrumb">
                        <li>
                            <ALink href="/">
                                <i className="d-icon-home"></i>
                            </ALink>
                        </li>
                        <li>Contact Us</li>
                    </ul>
                </div>
            </nav>

            <div className="page-content pt-3">
                <Reveal
                    keyframes={fadeIn}
                    delay="50"
                    duration="1000"
                    triggerOnce
                >
                    <section className="contact-section">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-3 col-md-4 col-sm-6 ls-m">
                                    <div className="grey-section d-flex align-items-center">
                                        <div>
                                            <h4 className="mb-2 text-capitalize">
                                                Headquarters
                                            </h4>
                                            <p>
                                                House-34, Rd No 19/A, Tajwar Center, Banani, Dhaka - 1212
                                            </p>

                                            <h4 className="mb-2 text-capitalize">
                                                Phone Number
                                            </h4>
                                            <p>
                                                <ALink href="#">
                                                    09677717171
                                                </ALink>
                                                {/* <br />
                                                <ALink href="#">
                                                    (9am to 6pm)
                                                </ALink> */}
                                            </p>

                                            <h4 className="mb-2 text-capitalize">
                                                Support
                                            </h4>
                                            <p className="mb-4">
                                                <ALink href="#">
                                                    info@futurebazar.com
                                                </ALink>
                                                <br />
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-9 col-md-8 col-sm-6 d-flex align-items-center mb-4">
                                    <div className="w-100">
                                        <form
                                            className="pl-lg-2"
                                            onSubmit={onSubmitForm}
                                        >
                                            <h4 className="ls-m font-weight-bold">
                                                Let’s Connect
                                            </h4>
                                            <p>
                                                Your email address will not be
                                                published. Required fields are
                                                marked *
                                            </p>
                                            <div className="row mb-2">
                                                <div className="col-12 mb-4">
                                                    <textarea
                                                        className="form-control"
                                                        required
                                                        placeholder="Comment*"
                                                        name="comment"
                                                        onChange={onChangeInput}
                                                        value={formdata ? formdata.comment : ""}
                                                    ></textarea>
                                                </div>
                                                <div className="col-md-6 mb-4">
                                                    <input
                                                        className="form-control"
                                                        type="text"
                                                        placeholder="Name *"
                                                        required
                                                        name="name"
                                                        onChange={onChangeInput}
                                                        value={formdata ? formdata.name : ""}
                                                    />
                                                </div>
                                                <div className="col-md-6 mb-4">
                                                    <input
                                                        className="form-control"
                                                        type="email"
                                                        placeholder="Email *"
                                                        required
                                                        name="email"
                                                        onChange={onChangeInput}
                                                        value={formdata ? formdata.email : ""}
                                                    />
                                                </div>
                                            </div>
                                            <button className="btn btn-dark btn-rounded">
                                                Post Comment
                                                <i className="d-icon-arrow-right"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </Reveal>

                <Reveal
                    keyframes={fadeIn}
                    delay="50"
                    duration="1000"
                    triggerOnce
                >
                    <div
                        className="grey-section google-map mt-5 mb-5"
                        id="googlemaps"
                        style={{ height: "386px" }}
                    >
                        <GoogleMapReact
                            bootstrapURLKeys={{
                                key: contactsConfigData?.GOOGLE_MAPS_API,
                            }}
                            defaultCenter={{ lat: 23.7465368, lng: 90.3955135 }}
                            defaultZoom={18}
                        >
                            <AnyReactComponent
                                lat={90.3955135}
                                lng={23.7465368}
                                text="My Marker"
                            />
                        </GoogleMapReact>
                    </div>
                </Reveal>
            </div>
        </main>
    );
}

export default ContactUs;
