import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { connect } from 'react-redux';
import Head from 'next/head';
import Image from "next/image";
import Card from '../../components/features/accordion/card';
import ALink from '../../components/features/custom-link';
import { useMutation, useQuery, useLazyQuery } from '@apollo/client';
import { SELLER_INFO_WITH_PRODUCTS, CATEGORY_PRODUCT_SEARCH_UNI } from '../../server/queries';
import ProductTwo from '../../components/product/product-two';
import Pagination from '../../components/features/pagination';

function Store(props) {
    // Props
    const { categoryList, itemsPerRow = 4 } = props;

    // States
    const [selectFirst, setSelectFirst] = useState();
    const [selectSecond, setSelectSecond] = useState();
    const [search, setSearch] = useState([]);
    const [products, setProducts] = useState([]);

    // Router
    const router = useRouter();
    const query = router.query;

    // Others
    const gridClasses = {
        3: "cols-2 cols-sm-3",
        4: "cols-2 cols-sm-3 cols-md-4",
        5: "cols-2 cols-sm-3 cols-md-4 cols-xl-5",
        6: "cols-2 cols-sm-3 cols-md-4 cols-xl-6",
        7: "cols-2 cols-sm-3 cols-md-4 cols-lg-5 cols-xl-7",
        8: "cols-2 cols-sm-3 cols-md-4 cols-lg-5 cols-xl-8",
    };

    // GraphQL Queries
    const [getSellerProducts, { data, loading, error }] = useLazyQuery(
        SELLER_INFO_WITH_PRODUCTS
    );
    const sellerDetails = data && data?.sellerDetails;
    const sellerProducts = data && data.sellerProductSerach;
    // const products = sellerProducts && sellerProducts.data;
    const paginatorInfo = sellerProducts && sellerProducts.paginatorInfo;
    const perPage = query.per_page ? parseInt(query.per_page) : 12;
    const page = query.page ? query.page : 1;

    const [serachProduct] = useMutation(CATEGORY_PRODUCT_SEARCH_UNI, {
        onError: ({ graphQLErrors, networkError, operation, forward }) => {
            if (graphQLErrors?.length) {
                console.log("graphQLErrors", graphQLErrors);
            }
        }
    });

    const handelFirstCat = (catId) => {
        if (selectFirst === catId) setSelectFirst(null);
        else setSelectFirst(catId);
    };

    const handelSecondCat = (sCatId) => {
        if (selectSecond === sCatId) setSelectSecond(null);
        else setSelectSecond(sCatId);
    };

    useEffect(() => {
        // Get products of selected seller/shop
        getSellerProducts({
            variables: {
                sellerId: query.slug,
                languageId: router.locale === "en" ? 1 : 2
            },
        });
    }, []);

    const generateSearchQuery = () => {
        let filterQuery = {
            language_id: router.locale === 'en' ? 1 : 2,
            "size": perPage,
            "page": page,
        };

        filterQuery.seller_id = query.slug;
        if (query.category) filterQuery.cat = query.category;

        return JSON.stringify(filterQuery);
    }

    const processSerchProduct = async () => {
        let res = await serachProduct({
            variables: {
                "searchQuery": generateSearchQuery()
            }
        });

        console.log("res?.data?.ProductSearchUni", res?.data?.ProductSearchUni);

        if (res?.data?.ProductSearchUni?.product) {
            let products = JSON.parse(res.data.ProductSearchUni.product);

            console.log("products", products);

            setSearch(res.data.ProductSearchUni);
            setProducts(products);
        }
    }

    useEffect(() => {
        processSerchProduct()
    }, [query]);

    return (
        <main className="main">
            <Head>
                <title>জমিলার দোকান - ইকমার্স স্টোর | পণ্য তালিকা</title>
            </Head>

            <nav className="breadcrumb-nav">
                <div className="container-fluid">
                    <ul className="breadcrumb">
                        <li>
                            <ALink href="/">
                                <i className="d-icon-home"></i>
                            </ALink>
                        </li>
                        <li>Shop</li>
                    </ul>
                </div>
            </nav>

            <div className="page-content mb-10 pb-7">
                <div className="container-fluid">
                    <div className="row">
                        <div
                            className="shop-banner banner"
                            style={{
                                backgroundImage: `${sellerDetails?.banner_url
                                        ? `url(${process.env
                                            .NEXT_PUBLIC_ASSET_URI +
                                        "/" +
                                        sellerDetails?.banner_url
                                        })`
                                        : "url(./images/store/seller-bg-2.png)"
                                    }`,
                                backgroundColor: "#EFEFEF",
                            }}
                        >
                            <div className="banner-content">
                                <h1 className="banner-title text-uppercase text-white font-weight-bold ls-l">
                                    {sellerDetails?.shop_name}
                                </h1>
                                <h4 className="banner-subtitle font-weight-normal text-white">
                                    <div className="ratings-container">
                                        <div className="ratings-full font-20">
                                            <span
                                                className="ratings"
                                                style={{
                                                    width:
                                                        20 *
                                                        (sellerDetails
                                                            ?.averageRatingCount
                                                            ?.ratingAverage ||
                                                            0) +
                                                        "%",
                                                }}
                                            ></span>
                                            <span className="tooltiptext tooltip-top">
                                                {sellerDetails
                                                    ?.averageRatingCount
                                                    ?.ratingAverage || 0}
                                            </span>
                                        </div>
                                        <a
                                            href="campagin-product-details.html"
                                            className="rating-reviews font-15"
                                        >
                                            ( Avg:{" "}
                                            {sellerDetails?.averageRatingCount
                                                ?.ratingAverage || "0.00"}{" "}
                                            )
                                        </a>
                                    </div>
                                </h4>
                            </div>
                        </div>
                    </div>

                    <div className="row main-content-wrap gutter-lg">
                        <aside className="col-lg-3 sidebar sidebar-fixed shop-sidebar sticky-sidebar-wrapper">
                            <div className="widget widget-collapsible for-mobile">
                                <h5 className="mt-5 mb-0 border-bottom-2 font-600">
                                    Categories
                                </h5>
                                <Card title="" type="parse" expanded={true}>
                                    <ul className="widget-body filter-items search-ul">
                                        {sellerDetails?.sellerCategories?.length ? (
                                            <>
                                                {sellerDetails?.sellerCategories.map(
                                                    (cat, index) => (
                                                        <li
                                                            key={"cate-" + index}
                                                        >
                                                            <ALink
                                                                href={{
                                                                    pathname:
                                                                        router.pathname,
                                                                    query: {
                                                                        ...query,
                                                                        category:
                                                                            cat
                                                                                ?.categoryInformation
                                                                                ?.url_key,
                                                                    },
                                                                }}
                                                            >
                                                                {cat
                                                                    ?.categoryInformation
                                                                    ?.icon ? (
                                                                    <div className="category-image-custom">
                                                                        <Image
                                                                            src={
                                                                                process
                                                                                    .env
                                                                                    .NEXT_PUBLIC_ASSET_URI +
                                                                                "/" +
                                                                                cat
                                                                                    ?.categoryInformation
                                                                                    ?.icon
                                                                            }
                                                                            alt="Picture of the author"
                                                                            width={
                                                                                24
                                                                            }
                                                                            height={
                                                                                25
                                                                            }
                                                                            quality={
                                                                                5
                                                                            }
                                                                        // placeholder="blur"
                                                                        />
                                                                    </div>
                                                                ) : (
                                                                    <i className="d-icon-shoppingbag category-procress-icon"></i>
                                                                )}
                                                                {
                                                                    cat
                                                                        ?.categoryInformation
                                                                        ?.categoryDetail[0]
                                                                        .name
                                                                }
                                                            </ALink>
                                                        </li>
                                                    )
                                                )}
                                            </>
                                        ) : ""}
                                    </ul>
                                </Card>
                            </div>
                        </aside>

                        <div className="col-lg-9 main-content pt-5">
                            {!products ? (
                                <div
                                    className={`row product-wrapper ${gridClasses[itemsPerRow]}`}
                                >
                                    {[
                                        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
                                    ].map((item) => (
                                        <div
                                            className="product-loading-overlay"
                                            key={"popup-skel-" + item}
                                        ></div>
                                    ))}
                                </div>
                            ) : (
                                ""
                            )}

                            {
                                <div
                                    className={`row product-wrapper ${gridClasses[itemsPerRow]}`}
                                >
                                    {products &&
                                        products.map((item) => (
                                            <div
                                                className="product-wrap"
                                                key={"shop-" + item._source.id}
                                            >
                                                <ProductTwo
                                                    product={item._source}
                                                    adClass=""
                                                    imageWidth={350}
                                                    imageHight={350}
                                                />
                                            </div>
                                        ))}
                                </div>
                            }

                            {products && products.length === 0 ? (
                                <p className="ml-1">
                                    No products were found matching your
                                    selection.
                                </p>
                            ) : (
                                ""
                            )}

                            {
                                search?.result_count > 0 ?
                                    <div className="toolbox toolbox-pagination" style={{ paddingLeft: "2rem", paddingRight: "2rem" }}>
                                        {
                                            <p className="show-info">Showing <span>
                                                {perPage * (page - 1) + 1} - {Math.min(perPage * page, search?.result_count)} of {search?.result_count}
                                            </span>Products</p>
                                        }

                                        <Pagination totalPage={Math.ceil(search?.result_count / perPage)} />
                                    </div> : ''
                            }
                        </div>
                    </div>
                </div>
            </div>
        </main>
    );
}

function mapStateToProps(state) {
    return {
        categoryList: state.category.data
    }
}

export default connect(mapStateToProps, {})(Store);
