import Head from 'next/head';
import { initializeApollo  } from "../server/apollo";
import NewsletterModal from "../components/features/modals/newsletter-modal"
// Import Apollo Server and Query
import { GET_HOME_DATA, GET_HOME_DATA_QUERY } from '../server/queries';

// import Home Components
import NewCollection from '../components/home/new-collection';
import IntroSection from '../components/home/intro-section';


export default function Home({ homeContent, meta }) {
  const product = homeContent && homeContent?.webStorefrontHomeContent;

  return (
    <div className="main home mt-lg-4 homepage">
      {/* <Head>
        <title> B71 - ECommerce Store </title>
      </Head> */}

      <div className="page-content">
          <IntroSection sliders={product?.slider} campaigns={product?.campaign}/>
          
          <div className='container-fluid'>
              {
                  product?.new_arrival_products?.length ? <NewCollection products={ product?.new_arrival_products || []} 
                  productTitle={"নতুন পণ্য"} zIndex_1={true} view="new-arrivals" loading={ !product?.new_arrival_products?.length } /> : ''
              }
              {
                  product?.best_selling_products?.length ? <NewCollection products={ product?.best_selling_products || []} 
                      productTitle={"সেরা বিক্রিত পণ্য"} view="best-selling" loading={ !product?.new_arrival_products?.length } /> : ''
              }

              {
                  product?.featured_products?.length ? <NewCollection products={ product?.featured_products || [] } 
                      productTitle={"ফিচার্ড পণ্য"} view="featured-products" loading={ !product?.new_arrival_products?.length } /> : ''
              }
          </div>
      </div>
      
      <NewsletterModal/>
    </div>
  )
}

export async function getStaticProps(ctx) {
  const apolloClient = initializeApollo();

  let homeContent = await apolloClient.query({
    query: GET_HOME_DATA,
    variables: {
      sliderPosition: 'home', 
      languageId: ctx?.locale === 'en' ? 1 : 2,
      first: 5 
    }
  });

  let metaTag = homeContent?.data?.webStorefrontHomeContent?.metaData;

  return {
    props: {
      homeContent: homeContent.data,
      meta: {
        "title": metaTag?.meta_title || '',
        "description": metaTag?.meta_description || '',
        "Keywords": metaTag?.meta_keyword || '',
      }
    },
    revalidate: 600,
  };
}
