import Document, { NextScript, Head, Main, Html } from 'next/document';
export default class MyDocument extends Document {
    render() {
        let pageProps = this.props?.__NEXT_DATA__?.props?.pageProps;

        let metaTags = {
            site_name: pageProps?.meta?.site_name || 'https://undp-bazar.com.bd/',
            title: pageProps?.meta?.title || 'আগামীর বাজার',
            description: pageProps?.meta?.description || "Agamir Bazar limited is an online marketplace that focuses on providing wide range of authentic products to its customers by maintaining a fast delivery channel.",
            image: pageProps?.meta?.image || process.env.NEXT_PUBLIC_CLIENT_URI + "/images/home/Group-34092.png",
            secure_url: pageProps?.meta?.secure_url || process.env.NEXT_PUBLIC_CLIENT_URI + "/images/home/Group-34092.png",
            Keywords: pageProps?.meta?.Keywords || '',
        };

        return (
            <Html lang="en">
                <Head>
                    {/* <title> { metaTags.title } </title> */}
                    <base href="/"></base>
                    <link rel="icon" href="images/icons/favicon.png" />

                    {/* Stylesheets should be imported inside style.scss file */}
                    {/* <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" /> */}
                    <link
                        rel="stylesheet"
                        type="text/css"
                        href="vendor/riode-fonts/riode-fonts.css"
                    />
                    <link
                        rel="stylesheet"
                        type="text/css"
                        href="vendor/fontawesome-free/css/all.min.css"
                    />
                    <link
                        rel="stylesheet"
                        type="text/css"
                        href="vendor/owl-carousel/owl.carousel.min.css"
                    />

                    <meta charSet="UTF-8" />
                    <meta
                        property="og:site_name"
                        content={metaTags.site_name}
                    />
                    <meta
                        name="Keywords"
                        content={metaTags.Keywords}
                    />
                    <meta name="Description" 
                        content={metaTags.description}/>
                        
                    <meta name="theme-color" content="#FF284F" />
                    <meta property="og:title" content={metaTags.title} />
                    <meta
                        property="og:description"
                        content={metaTags.description}
                    />
                    <meta property="og:image" content={metaTags.image} />
                    <meta
                        property="og:image:secure_url"
                        content={metaTags.secure_url}
                    />
                    <meta property="og:image:type" content="image/jpg" />
                    <meta property="og:image:width" content="1200" />
                    <meta property="og:image:height" content="627" />
                    <meta name="author" content="SSL Wireless"/>
                    {/* Developed By: Hasibul Hasan */}
                </Head>

                <body>
                    <Main />

                    {/* Scripts should be inside _app.js */}
                    <script src="./js/jquery.min.js"></script>
                    <script src="./js/slide-to-submit.js"></script>

                    {/* <script
                        src={"https://finbot.publicdemo.xyz/b71/bundle.min.js?v=" + new Date().getTime() }
                        ibot_key="ssl-eb580e4b-ce13-46ff"
                        id="ibot_id"
                    ></script> */}

                    {/* <script
                        src="https://finbot.publicdemo.xyz/b71/bundle.min.js?v=1.4"
                        ibot_key="ssl-eb580e4b-ce13-46ff"
                        data-user=''
                        id="ibot_id"
                    ></script> */}

                    <NextScript />
                </body>
            </Html>
        );
    }
}