import Head from 'next/head';
import Image from "next/image";
import Card from '../../components/features/accordion/card';
import ALink from '../../components/features/custom-link';

import { connect } from 'react-redux';
import { useState } from 'react';
// Language 
import useTranslation from "next-translate/useTranslation";

function CategoryMenu({ categoryList }) {
    const [selectFirst, setSelectFirst] = useState();
    const [selectSecond, setSelectSecond] = useState();
    let { t } = useTranslation();

    // setSelectFirst(cat.id)
    // setSelectSecond(catF.id)

    const handelFirstCat = (catId) => {
        if (selectFirst === catId) setSelectFirst(null);
        else setSelectFirst(catId);
    }

    const handelSecondCat = (sCatId) => {
        if (selectSecond === sCatId) setSelectSecond(null);
        else setSelectSecond(sCatId);
    }

    return (
        <main className="main">
            <Head>
                <title>জমিলার দোকান - ক্যাটাগরি</title>
            </Head>

            {/* <nav className="breadcrumb-nav">
                <div className="container-fluid">
                    <ul className="breadcrumb">
                        <li><ALink href="/"><i className="d-icon-home"></i></ALink></li>
                        <li>Categories</li>
                    </ul>
                </div>
            </nav> */}

            <div className="page-content mb-10 pb-7">
                <div className="container-fluid">
                    {
                        categoryList?.length ? <div className="widget widget-collapsible for-mobile">
                            <h5 className="mt-5 mb-0 border-bottom-2 font-600">{t("common:categories")}</h5>
                            <Card title="" type="parse" expanded={ true }>
                                <ul className="widget-body filter-items search-ul">
                                    {
                                        categoryList.map(cat => <li className={cat.children?.length ? "with-ul overflow-hidden" : ''} key={cat.url_key}>
                                            {/* href={ { pathname: '/s', query: { category: cat.url_key } } } */}
                                            <ALink href={`/category/${cat.url_key}`}>
                                                {
                                                    cat.icon ? <div className="category-image-custom">
                                                        <Image className="cat-image-custom"
                                                            src={ process.env.NEXT_PUBLIC_ASSET_URI + "/" + cat?.icon }
                                                            alt="Picture of the author"
                                                            // placeholder="blur"
                                                            width={24}
                                                            height={25}
                                                            quality={5}
                                                        />
                                                    </div> : <i className={"d-icon-shoppingbag"}></i>
                                                }
                                                { cat.label } 
                                            </ALink>
                                            { cat.children?.length ? 
                                                    <i className={`collapsed fas ${!(selectFirst === cat.id) ? 'fa-chevron-right' : 'fa-chevron-down'}`} onClick={() => handelFirstCat(cat.id)}></i>
                                                : '' } 
                                            {
                                                cat.children?.length ? <div className={`submenu-custom ${!(selectFirst === cat.id) ? 'd-none' : ''}`}>
                                                    <ul style={{display:'block'}}>
                                                        {
                                                           cat.children.map(catF => <li className="with-ul overflow-hidden" key={catF.url_key}>
                                                                {/* href={ { pathname: '/s', query: { category: catF.url_key } } } */}
                                                                <ALink href={`/category/${catF.url_key}`}>
                                                                    {
                                                                        catF.icon ? <div className="category-image-custom">
                                                                            <Image
                                                                                src={ process.env.NEXT_PUBLIC_ASSET_URI + "/" + catF?.icon }
                                                                                alt="Picture of the author"
                                                                                // placeholder="blur"
                                                                                width={24}
                                                                                height={25}
                                                                                quality={5}
                                                                            />
                                                                        </div> : <i className={"d-icon-shoppingbag"}></i>
                                                                    }
                                                                    { catF.label } 
                                                                </ALink>
                                                                
                                                                { catF.children?.length ? 
                                                                    <i className={`collapsed fas ${!(selectSecond === catF.id) ? 'fa-chevron-right' : 'fa-chevron-down'}`} onClick={() => handelSecondCat(catF.id)}></i> 
                                                                : ''}

                                                                {
                                                                    catF.children?.length ? <div className={`submenu-custom ${!(selectSecond === catF.id) ? 'd-none' : ''}`}>
                                                                        <ul style={{display:'block'}}>
                                                                            {
                                                                                catF?.children.map(catS => <li key={ 'cat-sub-' + catS.url_key }><ALink 
                                                                                    href={`/category/${catS.url_key}`}>
                                                                                        {/* href={ { pathname: '/s', query: { category: catS.url_key } } } */}
                                                                                    {
                                                                                        catS.icon ? <div className="category-image-custom">
                                                                                            <Image
                                                                                                src={ process.env.NEXT_PUBLIC_ASSET_URI + "/" + catS?.icon }
                                                                                                alt="Picture of the author"
                                                                                                // placeholder="blur"
                                                                                                width={24}
                                                                                                height={25}
                                                                                                quality={5}
                                                                                            />
                                                                                        </div> : <i className={"d-icon-shoppingbag"}></i>
                                                                                    }
                                                                                    { catS.label }
                                                                                </ALink></li>)
                                                                            }
                                                                        </ul>
                                                                    </div> : ''
                                                                }
                                                            </li>) 
                                                        }
                                                    </ul>
                                                </div> : ''
                                            }
                                        </li>)
                                    }
                                    {/* <li className="">
                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=backpacks-and-fashion-bags&amp;grid=&amp;type=">
                                            Backpacks &amp; Fashion Bags
                                        </a>
                                    </li>
                                    <li className="with-ul overflow-hidden">
                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=beauty-and-fragrance&amp;grid=&amp;type=">Beauty &amp; Fragrance <i className="fas fa-chevron-down collapsed"></i>
                                        </a>
                                        <div>
                                            <ul style={{display:'block'}}>
                                                <li className="with-ul overflow-hidden  ">
                                                <a href="/react/riode/demo-22/shop/right-sidebar/?category=hair-care&amp;grid=&amp;type=">Hair Care</a>
                                                </li>
                                                <li className="with-ul overflow-hidden  ">
                                                <a href="/react/riode/demo-22/shop/right-sidebar/?category=makeup&amp;grid=&amp;type=">Makeup <i className="fas fa-chevron-down collapsed"></i></a>
                                                <div>
                                                    <ul style={{display:'block'}}>
                                                        <li className="with-ul overflow-hidden  ">
                                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=hair-care&amp;grid=&amp;type=">Hair Care</a>
                                                        </li>
                                                        <li className="with-ul overflow-hidden  ">
                                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=makeup&amp;grid=&amp;type=">Makeup</a>
                                                        </li>
                                                        <li className="with-ul overflow-hidden  ">
                                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=beauty-new-arrivals&amp;grid=&amp;type=">New Arrivals</a>
                                                        </li>
                                                        <li className="with-ul overflow-hidden  ">
                                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=perfumes&amp;grid=&amp;type=">Perfumes</a>
                                                        </li>
                                                        <li className="with-ul overflow-hidden  ">
                                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=skin-care&amp;grid=&amp;type=">Skin Care</a>
                                                        </li>
                                                        <li className="with-ul overflow-hidden  ">
                                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=tools-and-equipments&amp;grid=&amp;type=">Tools &amp; Equipments</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                </li>
                                                <li className="with-ul overflow-hidden  ">
                                                <a href="/react/riode/demo-22/shop/right-sidebar/?category=beauty-new-arrivals&amp;grid=&amp;type=">New Arrivals</a>
                                                </li>
                                                <li className="with-ul overflow-hidden  ">
                                                <a href="/react/riode/demo-22/shop/right-sidebar/?category=perfumes&amp;grid=&amp;type=">Perfumes</a>
                                                </li>
                                                <li className="with-ul overflow-hidden  ">
                                                <a href="/react/riode/demo-22/shop/right-sidebar/?category=skin-care&amp;grid=&amp;type=">Skin Care</a>
                                                </li>
                                                <li className="with-ul overflow-hidden  ">
                                                <a href="/react/riode/demo-22/shop/right-sidebar/?category=tools-and-equipments&amp;grid=&amp;type=">Tools &amp; Equipments</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li className="">
                                        <a href="/react/riode/demo-22/shop/right-sidebar/?category=shoes&amp;grid=&amp;type=">Shoes</a>
                                    </li> */}
                                </ul>
                            </Card>
                        </div> : ''
                    }
                </div>
            </div>
        </main >
    )
}

function mapStateToProps( state ) {
    return {
        categoryList: state.category.data
    }
}

export default connect( mapStateToProps, { } )( CategoryMenu );