import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import ALink from "../../components/features/custom-link";
import { useQuery, useLazyQuery } from "@apollo/client";
import imagesLoaded from "imagesloaded";
import {
    GET_PRODUCT_INFO,
    GET_PRODUCT_INFO_QUERY,
    PRODUCT_IDS_SKUS,
    CMS_CONTENT_QUERY,
} from "../../server/queries";
import { initializeApollo } from "../../server/apollo";
import OwlCarousel from "../../components/features/owl-carousel";
import ProductSidebar from "../../components/product/product-sidebar";
import MediaFive from "../../components/product/media/media";
import DetailThree from "../../components/product/detail/detail";
import DescOne from "../../components/product/desc/desc-one";
import NewCollection from "../../components/home/new-collection";
import { mainSlider17 } from "../../utils/data/carousel";
import { productImage } from "../../utils";

function ProductStickyInfo(props) {
    // Props
    const { 
        content,
        metaTags,
        cmsDetails
    } = props;

    // States
    const [selectedVarient, setSelectedVarient] = useState(null);
    const [loaded, setLoadingState] = useState(false);

    // Router
    const router = useRouter();
    const { query } = router;
    const slug = query.slug;
    const selectedVariantID = query.selectedVariant
        ? parseInt(query.selectedVariant)
        : null;

    // Others
    const product = content && content.product ? content.product : null;
    const related =
        product && product?.relatedProduct ? product?.relatedProduct : []; // remove in future
    const filteredVariation = selectedVariantID
        ? product?.productVariation?.filter(
              (item) => item.id === selectedVariantID
          )
        : null;

    const chnageVarient = (varients) => {
        setSelectedVarient(varients);
    };

    useEffect(() => {
        if (product) {
            imagesLoaded("main")
                .on("done", function () {
                    setLoadingState(true);
                })
                .on("progress", function () {
                    setLoadingState(false);
                });
        }
        if (!product) setLoadingState(false);
    }, [product]);

    useEffect(() => {
        if (selectedVariantID) {
            setSelectedVarient([selectedVariantID]);
        }
    }, []);

    if (!slug) return "";
    if (!product || product?.status === 0)
        return (
            <div className="page-content">
                <section
                    className="error-section d-flex flex-column justify-content-center align-items-center text-center pl-3 pr-3"
                    style={{ marginTop: "10%", marginBottom: "10%" }}
                >
                    <h1 className="mb-2 ls-m">Error 404</h1>
                    <img
                        src="./images/subpages/404.png"
                        alt="error 404"
                        width="609"
                        height="131"
                    />
                    <h4 className="mt-7 mb-0 ls-m text-uppercase">
                        Ooopps! That page can’t be found.
                    </h4>
                    <p className="text-grey font-primary ls-m">
                        It looks like nothing was found at this location.
                    </p>
                    <ALink
                        href="/"
                        className="btn btn-primary btn-rounded mb-4"
                    >
                        Go home
                    </ALink>
                </section>
            </div>
        );

    return (
        <main className="main single-product custom-bg-color-one pt-5">
            <Head>
                <title> {product?.productDetail[0]?.name} </title>
            </Head>

            {product ? (
                <div className={`page-content single-product-content`}>
                    <div className="container-fluid skeleton-body">
                        <div className="row">
                            <ProductSidebar
                                shippingCharge={product?.shippingCharge}
                                warrenty={product?.warrenty}
                            />

                            <div className="col-lg-9">
                                <div className="product product-single pt-4 pr-4 pb-4 pl-4 mb-4 bg-white">
                                    <div className="row">
                                        <div className="col-md-6">
                                            <MediaFive
                                                product={product}
                                                adClass="pb-0"
                                                selectedVarient={
                                                    selectedVarient
                                                }
                                            />
                                        </div>

                                        <div className="col-md-6">
                                            <DetailThree
                                                data={content}
                                                changeVarient={chnageVarient}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <DescOne 
                                product={product} 
                                isDivider={false} 
                                cmsDetails={cmsDetails}
                            />
                        </div>
                        {related?.length ? (
                            <div className="row mt-4 related-product">
                                <div className="col-lg-12">
                                    <NewCollection
                                        products={related}
                                        productTitle={"Related Products"}
                                        addClass={"pl-3 pr-3"}
                                    />
                                </div>
                            </div>
                        ) : (
                            ""
                        )}
                    </div>
                </div>
            ) : (
                ""
            )}
            {product ? (
                ""
            ) : (
                <div className="skeleton-body container mb-10">
                    <div className="row mt-8 gutter-lg">
                        <div className="col-lg-3 right-sidebar sidebar-fixed sticky-sidebar-wrapper">
                            <div className="sidebar-content">
                                <div className="widget-2"></div>
                            </div>
                        </div>
                        <div className="col-lg-9">
                            <div className="row mb-4">
                                <div className="col-md-6">
                                    <div className="skel-pro-gallery"></div>
                                </div>

                                <div className="col-md-6">
                                    <div className="skel-pro-summary"></div>
                                </div>
                            </div>

                            <div className="skel-pro-tabs"></div>

                            <section className="pt-3 mt-4">
                                <h3 className="title justify-content-center">
                                    সংশ্লিষ্ট পণ্য
                                </h3>
                                <OwlCarousel
                                    adClass="owl-carousel owl-theme owl-nav-full"
                                    options={mainSlider17}
                                >
                                    {[1, 2, 3, 4, 5, 6].map((item) => (
                                        <div
                                            className="product-loading-overlay"
                                            key={"popup-skel-" + item}
                                        ></div>
                                    ))}
                                </OwlCarousel>
                            </section>
                        </div>
                    </div>
                </div>
            )}
        </main>
    );
}

export const getStaticPaths = async () => {
    const apolloClient = initializeApollo();

    let pagePaths = [];
    let paths = await apolloClient.query({
        query: PRODUCT_IDS_SKUS,
        variables: {
            "first": 200,
            "page": 1
        }
    });

    let productPages = paths?.data?.productsIdsSkus?.data || [];

    productPages.forEach((product) => {
        pagePaths.push({ params: { slug: product.prod_sku } });
    });

    return {
        paths: pagePaths,
        fallback: "blocking",
    };
};

export const getStaticProps = async (context) => {
    const apolloClient = initializeApollo();

    let content = await apolloClient.query({
        query: GET_PRODUCT_INFO,
        variables: {
            languageId: context?.locale === "en" ? 1 : 2,
            urlKey: context.params?.slug,
            first: 10000,
        },
    });

    let returnAndWarrantyPolicy = await apolloClient.query({
        query: CMS_CONTENT_QUERY,
        variables: {
            languageId: context?.locale === "en" ? 1 : 2,
            slug: "return-and-warranty-policy",
        },
    });

    let purchasePolicy = await apolloClient.query({
        query: CMS_CONTENT_QUERY,
        variables: {
            languageId: context?.locale === "en" ? 1 : 2,
            slug: "purchase-policy",
        },
    });

    let deliveryPolicy = await apolloClient.query({
        query: CMS_CONTENT_QUERY,
        variables: {
            languageId: context?.locale === "en" ? 1 : 2,
            slug: "delivery-policy",
        },
    });

    let replacePolicy = await apolloClient.query({
        query: CMS_CONTENT_QUERY,
        variables: {
            languageId: context?.locale === "en" ? 1 : 2,
            slug: "replace-policy",
        },
    });

    const product =
        content && content?.data && content?.data.product
            ? content?.data.product
            : null;

    return {
        props: {
            content: content?.data,
            meta: {
                title: product?.meta_title || "",
                description: product?.meta_description || "",
                Keywords: product?.meta_keyword || "",
                image: productImage(product),
                secure_url: productImage(product),
                site_name: `${
                    (process.env.NEXT_PUBLIC_CLIENT_URI ||
                        "https://b71-stage.sslwireless.com") +
                    "/product/" +
                    product?.url_key
                }`,
            },
            cmsDetails: {
                returnAndWarrantyPolicy: returnAndWarrantyPolicy?.data?.cmsDetails?.cmsDetails[0]?.content,
                purchasePolicy: purchasePolicy?.data?.cmsDetails?.cmsDetails[0]?.content,
                deliveryPolicy: deliveryPolicy?.data?.cmsDetails?.cmsDetails[0]?.content,
                replacePolicy: replacePolicy?.data?.cmsDetails?.cmsDetails[0]?.content,
            }
        },
        revalidate: 600,
    };
};

export default ProductStickyInfo;
