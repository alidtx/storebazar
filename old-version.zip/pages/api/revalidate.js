const https = require('https');

export default async function handler(req, res) {
    // Check for secret to confirm this is a valid request
    if (req.query.secret !== process.env.NEXT_PUBLIC_SECRET_TOKEN ) {
      return res.status(401).json({ message: 'Invalid token' })
    }

    try {
      await res.unstable_revalidate('/product/' + req.query.slug);
      // return res.json({ revalidated: true })

      // http://localhost:3003/revalidate/?secret=b71_secret_token_SSL_1399&slug=gucci-bag-38-36

      https.get(process.env.NEXT_PUBLIC_CLIENT_URI + '/product/' + req.query.slug, (resp) => {
        // console.log("resp ==", resp);
      });

      return res.json({ revalidated: true })
    } catch (err) {

        console.log("errrr", err);

      // If there was an error, Next.js will continue
      // to show the last successfully generated page
      return res.status(500).send('Error revalidating')
    }
}