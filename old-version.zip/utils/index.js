/**
 * utils to parse options string to object
 * @param {string} options 
 * @return {object}
 */
import moment from "moment";
import { findMinQTY } from "./helpers";

export const parseOptions = function (options) {
    if ("string" === typeof options) {
        return JSON.parse(options.replace(/'/g, '"').replace(';', ''));
    }
    return {};
}

/**
 * utils to dectect IE browser
 * @return {bool}
 */
export const isIEBrowser = function () {
    let sUsrAg = navigator.userAgent;
    if (sUsrAg.indexOf("Trident") > -1) {
        return true;
    }

    return false;
}

/**
 * utils to detect safari browser
 * @return {bool}
 */
export const isSafariBrowser = function () {
    let sUsrAg = navigator.userAgent;
    if (sUsrAg.indexOf('Safari') !== -1 && sUsrAg.indexOf('Chrome') === -1)
        return true;
    return false;
}

/**
 * utils to detect Edge browser
 * @return {bool}
 */
export const isEdgeBrowser = function () {
    let sUsrAg = navigator.userAgent;
    if (sUsrAg.indexOf("Edge") > -1)
        return true;
    return false;
}

/**
 * utils to find index in array
 * @param {array} array
 * @param {callback} cb
 * @returns {number} index
 */
export const findIndex = function (array, cb) {
    for (let i = 0; i < array.length; i++) {
        if (cb(array[i])) {
            return i;
        }
    }
    return -1;
}

/**
 * utils to get the position of the first element of search array in array
 * @param {array} array
 * @param {array} searchArray
 * @param {callback} cb
 * @returns {number} index
 */
export const findArrayIndex = function (array, searchArray, cb) {
    for (let i = 0; i < searchArray.length; i++) {
        if (cb(searchArray[i])) {
            return i;
        }
    }
    return -1;
}


/**
 * utils to remove all XSS  attacks potential
 * @param {String} html
 * @return {Object}
 */
export const parseContent = (html) => {
    const SCRIPT_REGEX = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi;

    //Removing the <script> tags
    while (SCRIPT_REGEX.test(html)) {
        html = html.replace(SCRIPT_REGEX, '');
    }

    //Removing all events from tags...
    html = html.replace(/ on\w+="[^"]*"/g, '');

    return {
        __html: html
    }
}

/**
 * Apply sticky header
 */
export const stickyHeaderHandler = function () {
    let top = document.querySelector('main') ? document.querySelector('main').offsetTop : 300;

    let stickyHeader = document.querySelector('.sticky-header');
    let height = 0;

    if (stickyHeader) {
        height = stickyHeader.offsetHeight;
    }

    if (window.pageYOffset >= top && window.innerWidth >= 992) {
        if (stickyHeader) {
            stickyHeader.classList.add('fixed');
            if (!document.querySelector('.sticky-wrapper')) {
                let newNode = document.createElement("div");
                newNode.className = "sticky-wrapper";
                stickyHeader.parentNode.insertBefore(newNode, stickyHeader);
                document.querySelector('.sticky-wrapper').insertAdjacentElement('beforeend', stickyHeader);
                document.querySelector('.sticky-wrapper').setAttribute("style", "height: " + height + "px");
            }

            if (!document.querySelector('.sticky-wrapper').getAttribute("style")) {
                document.querySelector('.sticky-wrapper').setAttribute("style", "height: " + height + "px");
            }
        }
    } else {
        if (stickyHeader) {
            stickyHeader.classList.remove('fixed');
        }

        if (document.querySelector('.sticky-wrapper')) {
            document.querySelector('.sticky-wrapper').removeAttribute("style");
        }
    }

    if (window.outerWidth >= 992 && document.querySelector('body').classList.contains('right-sidebar-active')) {
        document.querySelector('body').classList.remove('right-sidebar-active');
    }
}

/**
 * Add or remove settings when the window is resized
 */
export const resizeHandler = function (width = 992, attri = 'right-sidebar-active') {
    let bodyClasses = document.querySelector("body") && document.querySelector("body").classList;
    bodyClasses = bodyClasses.value.split(' ').filter(item => item !== 'home' && item !== 'loaded');
    for (let i = 0; i < bodyClasses.length; i++) {
        document.querySelector("body") && document.querySelector('body').classList.remove(bodyClasses[i]);
    }
}

/**
 * Apply sticky footer
 */
export const stickyFooterHandler = function () {
    let stickyFooter = document.querySelector('.sticky-footer');
    let top = document.querySelector('main') ? document.querySelector('main').offsetTop : 300;

    let height = 0;

    if (stickyFooter) {
        height = stickyFooter.offsetHeight;
    }

    if (window.pageYOffset >= top && window.innerWidth < 768) {
        if (stickyFooter) {
            stickyFooter.classList.add('fixed');
            if (!document.querySelector('.sticky-content-wrapper')) {
                let newNode = document.createElement("div");
                newNode.className = "sticky-content-wrapper";
                stickyFooter.parentNode.insertBefore(newNode, stickyFooter);
                document.querySelector('.sticky-content-wrapper').insertAdjacentElement('beforeend', stickyFooter);
            }

            document.querySelector('.sticky-content-wrapper').setAttribute("style", "height: " + height + "px");
        }
    } else {
        if (stickyFooter) {
            stickyFooter.classList.remove('fixed');
        }

        if (document.querySelector('.sticky-content-wrapper')) {
            document.querySelector('.sticky-content-wrapper').removeAttribute("style");
        }
    }

    if (window.innerWidth > 768 && document.querySelector('.sticky-content-wrapper')) {
        document.querySelector('.sticky-content-wrapper').style.height = 'auto';
    }
}

/**
 * utils to make background parallax
 */
export const parallaxHandler = function () {
    let parallaxItems = document.querySelectorAll('.parallax');

    if (parallaxItems) {
        for (let i = 0; i < parallaxItems.length; i++) {
            // calculate background y Position;
            let parallax = parallaxItems[i], yPos, parallaxSpeed = 1;

            if (parallax.getAttribute('data-option')) {
                parallaxSpeed = parseInt(parseOptions(parallax.getAttribute('data-option')).speed);
            }

            yPos = (parallax.offsetTop - window.pageYOffset) * 50 * parallaxSpeed / parallax.offsetTop + 50;

            parallax.style.backgroundPosition = "50% " + yPos + "%";
        }
    }
}

/**
 * utils to show scrollTop button
 */
export const showScrollTopHandler = function () {
    let scrollTop = document.querySelector(".scroll-top");

    if (window.pageYOffset >= 768) {
        scrollTop.classList.add("show");
    } else {
        scrollTop.classList.remove("show");
    }
}

/**
 * utils to scroll to top
 */
export function scrollTopHandler(isCustom = true, speed = 15) {
    let offsetTop = 0;

    if (isCustom && !isEdgeBrowser()) {
        if (document.querySelector('.main .container > .row')) {
            offsetTop = document.querySelector('.main .container > .row').getBoundingClientRect().top + window.pageYOffset - document.querySelector('.sticky-header').offsetHeight + 2;
        }
    } else {
        offsetTop = 0;
    }

    if (isSafariBrowser() || isEdgeBrowser()) {
        let pos = window.pageYOffset;
        let timerId = setInterval(() => {
            if (pos <= offsetTop) clearInterval(timerId);
            window.scrollBy(0, -speed);
            pos -= speed;
        }, 1);
    } else {
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

/**
 * utils to play and pause video
 */
export const videoHandler = (e) => {
    e.stopPropagation();
    e.preventDefault();

    if (e.currentTarget.closest('.post-video')) {
        let video = e.currentTarget.closest('.post-video');
        if (video.classList.contains('playing')) {
            video.classList.remove('playing');
            video.classList.add('paused');
            video.querySelector('video').pause();
        } else {
            video.classList.add('playing');
            video.querySelector('video').play();
        }

        video.querySelector('video').addEventListener('ended', function () {
            video.classList.remove('playing');
            video.classList.remove('paused');
        })
    }
}

/**
 * utils to get total Price of products in cart.
 */
export const getTotalPrice = cartItems => {
    let total = 0;
    if (cartItems) {
        for (let i = 0; i < cartItems.length; i++) {
            total += cartItems[i]?.productVariation?.price * parseInt(cartItems[i].qty, 10);
        }
    }
    return total;
}

export const getTotalPriceFromCart = cartItems => {
    let total = 0;
    if (cartItems) {
        for (let i = 0; i < cartItems.length; i++) {
            total += originalPriceFromCart(cartItems[i]) * parseInt(cartItems[i].qty, 10);
        }
    }
    return total;
}

export const originalPriceFromCart = cart => {
    if (cart) {
        let variation = cart.productVariation;
        if (variation) {
            if (canShowSpecialPrice(variation)) {
                return canShowSpecialPrice(variation);
            } else if (variation.bulkQuantityPrice && variation.bulkQuantityPrice.length) {
                let bulk = variation.bulkQuantityPrice,
                    qty = cart.qty,
                    item = null;
                
                let bulkQuantityPrice = bulk.sort(function (a, b) {
                    return a.min_qty - b.min_qty;
                });
                
                for (let i = 0; i < bulkQuantityPrice.length; i++) {
                    if (bulkQuantityPrice[i] && bulkQuantityPrice[i].min_qty > qty) {
                        return variation.price;
                    } else if (bulkQuantityPrice[i] && bulkQuantityPrice[i + 1] &&
                            bulkQuantityPrice[i].min_qty <= qty && bulkQuantityPrice[i + 1].min_qty > qty) {
                        item = bulkQuantityPrice[i];
                        break;
                    } else if (bulkQuantityPrice[i] && !bulkQuantityPrice[i + 1]) {
                        item = bulkQuantityPrice[i];
                    }
                }

                return item?.unit_price || 0;
            } else return variation.price;
        } else return 0;
    } else return 0;
}

export const canShowSpecialPrice = (variation) => {
    if (variation) {
        if (variation.campaignPrice && variation.campaignPrice?.campaign &&
            variation.campaignPrice?.campaign?.end_date && variation.campaignPrice?.campaign?.start_date &&
            moment().isAfter(variation.campaignPrice?.campaign?.start_date) && moment().isBefore(variation.campaignPrice?.campaign?.end_date)) {
            return variation.campaignPrice.discount_price;

        }
        else if (variation.special_price_end && variation.special_price_start) {
            if (moment().isAfter(variation.special_price_start) && moment().isBefore(variation.special_price_end)) {
                return variation.special_price || 0;
            } return 0;
        } else return 0;
    } else return 0;
};

export const extraPriceFromCart = cart => {
    if (cart) {
        let productVariation = cart.productVariation;
        if (originalPriceFromCart(cart) === productVariation.price) return 0;
        else return productVariation.price;
    } else return 0;
}

/**
 * utils to get number of products in cart
 */
export const getCartCount = cartItems => {
    let total = 0;

    for (let i = 0; i < cartItems?.length; i++) {
        total += parseInt(cartItems[i].qty, 10);
    }

    return total;
}

/**
 * utils to show number to n places of decimals
 */
export const toDecimal = (price, fixedCount = 2) => {
    if (price) return price.toLocaleString(undefined, { minimumFractionDigits: fixedCount, maximumFractionDigits: fixedCount });
}

export const productImage = (product, varientId) => {
    if (product?.productVariation) {
        if (varientId) {
            let productVariation = product.productVariation;
            let findProduct = productVariation.find(varia => varia.id == varientId);

            if (findProduct && findProduct.productVariationImage && findProduct.productVariationImage[0]?.image_path) {
                return process.env.NEXT_PUBLIC_ASSET_URI + "/" + findProduct.productVariationImage[0]?.image_path;
            } else {
                return "/images/B71_02.png";
            }
        } else if (product?.productVariation[0]?.productVariationImage) {
            if (product?.productVariation[0]?.productVariationImage[0]) {
                if (product?.productVariation[0]?.productVariationImage[0]?.image_path) {
                    return process.env.NEXT_PUBLIC_ASSET_URI + "/" + product?.productVariation[0]?.productVariationImage[0]?.image_path;
                } else return "/images/B71_02.png";
            } else return "/images/B71_02.png";
        } else return "/images/B71_02.png";
    } else return "/images/B71_02.png";
}

export const orderStatusShow = (status) => {
    let text = "";

    switch (status) {
        case "ORDER_PLACED":
            text = "Order Placed";
            break;
        case "CONFIRMED":
            text = "Confirmed";
            break;
        case "PROCESSING":
            text = "Processing";
            break;
        case "PICKED":
            text = "Picked";
            break;
        case "READY_TO_SHIPPED":
            text = "Ready To Shipped";
            break;
        case "SHIPPED":
            text = "Shipped";
            break;
        case "SHIPPED_TO_3PL":
            text = "Shipped To 3PL";
            break;
        case "DELIVERED":
            text = "Delivered";
            break;
        case "CANCELLED":
            text = "Cancelled";
            break;
        case "HOLD":
            text = "Hold";
            break;
        case "CANCELLED_BY_CUSTOMER":
            text = "Cancelled By Customer";
            break;
        case "CANCELLED_BY_SELLER":
            text = "Cancelled By Seller";
            break;
        case "RETURNED":
            text = "Returned";
            break;
        case "RETURN_REQUESTED":
            text = "Return Requested";
            break;
        case "RETURN_APPROVED":
            text = "Return Approved";
            break;
        case "RETURN_DENIED":
            text = "Return Denied";
            break;
        case "RETURN_RESOLVED":
            text = "Return Resolved";
            break;
        case "REFUND_REQUESTED":
            text = "Refund Requested";
            break;
        case "REFUND_APPROVED":
            text = "Refund Approved";
            break;
        case "REFUND_RESOLVED":
            text = "Refund Resolved";
            break;
        case "REFUND_DENIED":
            text = "Refund Denied";
            break;
        case "REFUNDED":
            text = "Refunded";
            break;
        default:
            text = "";
    }

    return text;
}

export const willOverflowProductStock = (varientId, cartList, quantity) => {
    let foundVariant = cartList?.find(cartItem => cartItem.variation_id === varientId);

    if (foundVariant) {
        let productStockQty = findMinQTY(foundVariant.productVariation.qty, foundVariant.productVariation.maximum_order_quantity);// foundVariant.productVariation.qty;
        let totalQtyAfterAdd = foundVariant.qty + quantity;

        if (totalQtyAfterAdd > productStockQty) {
            return true;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

export const isInstock = (product, selectedvariation) => {
    let productVariation = product?.productVariation;

    if (productVariation) {
        if (selectedvariation) {
            let findVari = productVariation.find(vari => vari.id === selectedvariation);

            if (findVari) {
                return !!findVari.qty;
            } else return false;
        } else {
            let variation = productVariation[0] || null;

            if (variation) {
                return !!variation.qty;
            } else return false;
        }
    } else return false;
}

export const isUnderCampaign = (campaign) => {
    if (
        campaign &&
        campaign.end_date &&
        campaign.start_date &&
        moment().isAfter(campaign.start_date) &&
        moment().isBefore(campaign.end_date)
    ) {
        return true;
    } else {
        return false;
    }
};

export const isEmptyObject = (obj) => {
    return Object.keys(obj).length === 0 && obj.constructor === Object;
};

export const isEmptyObj = (obj) => {
    return Object.keys(obj).length === 0;
}