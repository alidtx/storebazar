docker build . -t undp-bazar-storefront:pilot2
docker container rm undp_bazar_storefront
docker run -p 3031:3000 --name=undp_bazar_storefront undp-bazar-storefront:pilot