pwd
#git pull
#docker build . --platform linux/amd64 -t 586053531020.dkr.ecr.ap-southeast-1.amazonaws.com/b71-prod-storefront:latest
docker image push 586053531020.dkr.ecr.ap-southeast-1.amazonaws.com/b71-prod-storefront:latest
#docker run --name b71storefront-prod -p 3000:3000 586053531020.dkr.ecr.ap-southeast-1.amazonaws.com/b71-prod-storefront
# docker container stop b71storefront-prod
# docker container rm b71storefront-prod
# docker image rm 586053531020.dkr.ecr.ap-southeast-1.amazonaws.com/b71-prod-storefront:latest

scp -P 2322 root@192.168.63.18:/root/admin-storage.zip ~/Downloads
aws s3 cp s3://b71-sandbox/storefront-prod/.env /app/