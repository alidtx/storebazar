
export const FILE_UPLOAD = "/api/temporary-upload";