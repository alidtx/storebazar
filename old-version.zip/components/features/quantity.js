import { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { toast } from "react-toastify";

function Quantity(props) {
    // Props
    const {
        adClass = "input-group",
        qty = 1,
        cartList,
        product,
        context,
        onChangeQty,
        max,
        disableButtonActions,
    } = props;

    // States
    const [quantity, setQuantity] = useState();

    // useEffect( () => {
    //     setQuantity( qty );
    // }, [ product ] )

    useEffect(() => {
        if (context === "product") setQuantity(parseInt(qty));
    }, [qty]);

    useEffect(() => {
        if (product && cartList.length) {
            if (context === "product") {
                // let cartProduct = cartList.find(cart => cart?.productVariation?.product_id === product?.id);
                // if (cartProduct?.qty) setQuantity(cartProduct.qty);
                // else
                setQuantity(1);
            }
            if (context === "cart") {
                let cartProduct = cartList.find(
                    (cart) => cart?.variation_id === product?.variation_id
                );
                if (cartProduct?.qty) setQuantity(cartProduct.qty);
                else setQuantity(1);
            }
        }
    }, [cartList, product]);

    function minusQuantity() {
        if (quantity > 1) {
            setQuantity(parseInt(quantity) - 1);
            if (context === "product") onChangeQty(parseInt(quantity) - 1);
            else onChangeQty(-1);
        }
    }

    function plusQuantity() {
        if (quantity < max) {
            setQuantity(parseInt(quantity) + 1);
            if (context === "product") {
                onChangeQty(parseInt(quantity) + 1);
            } else {
                onChangeQty(1);
            }
        } else {
            toast.error(<span> &nbsp; Already added maximum quantity of this product to cart! &nbsp; </span>);
        }
    }

    function changeQty(e) {
        let newQty;

        if (e.currentTarget.value !== "") {
            newQty = Math.min(parseInt(e.currentTarget.value), max);
            newQty = Math.max(newQty, 1);
            // setQuantity( newQty );
        }
    }

    return (
        <div className={adClass}>
            <button
                className="quantity-minus d-icon-minus"
                onClick={minusQuantity}
                disabled={disableButtonActions}
            ></button>
            <input
                className="quantity form-control"
                type="number"
                id="js-quantity-value"
                min="1"
                disabled
                max={max}
                value={quantity}
                onChange={changeQty}
            />
            <button
                className="quantity-plus d-icon-plus"
                onClick={plusQuantity}
                disabled={disableButtonActions}
            ></button>
        </div>
    );
}

function mapStateToProps( state ) {
    return {
        cartList: state.cart.data
    }
}

export default connect( mapStateToProps, {} )( Quantity );
