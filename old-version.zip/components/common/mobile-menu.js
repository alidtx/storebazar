import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { connect } from 'react-redux';
import ALink from '../features/custom-link';
import Card from "../features/accordion/card"

// Language 
import useTranslation from "next-translate/useTranslation";

import { mainMenu } from '../../utils/data/menu';


function MobileMenu(props) {
    const { categoryList, mobileMenuContent } = props;
    console.log("mobileMenuContent =", mobileMenuContent);

    const content = mobileMenuContent && mobileMenuContent.cmsDetails && mobileMenuContent.cmsDetails?.cmsDetails[0]?.content ? mobileMenuContent.cmsDetails?.cmsDetails[0]?.content : '';


    let { t } = useTranslation();
    const [search, setSearch] = useState("");
    const router = useRouter();

    useEffect(() => {
        window.addEventListener('resize', hideMobileMenuHandler);
        document.querySelector("body").addEventListener("click", onBodyClick);

        return () => {
            window.removeEventListener('resize', hideMobileMenuHandler);
            document.querySelector("body").removeEventListener("click", onBodyClick);
        }
    }, [])

    useEffect(() => {
        setSearch("");
    }, [router.query.slug])

    const hideMobileMenuHandler = () => {
        if (window.innerWidth > 991) {
            document.querySelector('body').classList.remove('mmenu-active');
        }
    }

    const hideMobileMenu = () => {
        document.querySelector('body').classList.remove('mmenu-active');
    }

    function onSearchChange(e) {
        setSearch(e.target.value);
    }

    function onBodyClick(e) {
        if (e.target.closest('.header-search')) return e.target.closest('.header-search').classList.contains('show-results') || e.target.closest('.header-search').classList.add('show-results');

        document.querySelector('.header-search.show') && document.querySelector('.header-search.show').classList.remove('show');
        document.querySelector('.header-search.show-results') && document.querySelector('.header-search.show-results').classList.remove('show-results');
    }

    function onSubmitSearchForm(e) {
        e.preventDefault();
        router.push({
            pathname: '/s',
            query: {
                search: search
            }
        });
    }

    return (
        <div className="mobile-menu-wrapper">
            <div className="mobile-menu-overlay" onClick={hideMobileMenu}>
            </div>

            <ALink className="mobile-menu-close" href="#" onClick={hideMobileMenu}><i className="d-icon-times"></i></ALink>

            {/* <div dangerouslySetInnerHTML={{ __html: content }} /> */}

            <div className="mobile-menu-container scrollable d-none">


                <ul className="mobile-menu mmenu-anim ">
                    <li>
                        <ALink href="/">{t("common:home")}</ALink>
                    </li>
                    <li>
                        <a href="/shop/">{t("common:categories")}
                            <span className="toggle-btn collapsed"></span>
                        </a>
                        {/* style="overflow: hidden; display: none;" */}
                        <div className="overflow-hidden" style={{ overflow: 'hidden', display: "none" }}>
                            <ul>
                                <li>
                                    <a href="/category/menu/#">Variations 1
                                        <span className="toggle-btn collapsed">
                                        </span>
                                    </a>
                                    {/* style="overflow: hidden; display: none;" */}
                                    <div className="overflow-hidden" style={{ overflow: 'hidden', display: "none" }}>
                                        <ul>
                                            <li>
                                                <a href="/shop/banner-sidebar/">Banner With Sidebar</a>
                                            </li>
                                            <li><a href="/shop/boxed-banner/">Boxed Banner</a></li>
                                            <li><a href="/shop/infinite-scroll/">Infinite Ajaxscroll</a></li>
                                            <li><a href="/shop/horizontal-filter/">Horizontal Filter</a></li>
                                            <li><a href="/shop/navigation-filter/">Navigation Filter
                                                <span className="tip tip-hot">Hot</span></a></li>
                                            <li><a href="/shop/off-canvas-filter/">Off-Canvas Filter</a></li>
                                            <li><a href="/shop/right-sidebar/">Right Toggle Sidebar</a></li>
                                        </ul></div></li><li><a href="/category/menu/#">Variations 2
                                            <span className="toggle-btn collapsed"></span>
                                        </a>
                                    {/* style="overflow: hidden; display: none;" */}
                                    <div className="overflow-hidden" style={{ overflow: 'hidden', display: "none" }}><ul><li>
                                        <a href="/shop/grid/3cols/">3 Columns Mode
                                            <span className="tip tip-new">New</span></a></li><li>
                                            <a href="/shop/grid/4cols/">4 Columns Mode</a></li>
                                        <li><a href="/shop/grid/5cols/">5 Columns Mode</a></li>
                                        <li><a href="/shop/grid/6cols/">6 Columns Mode</a></li>
                                        <li><a href="/shop/grid/7cols/">7 Columns Mode</a></li>
                                        <li><a href="/shop/grid/8cols/">8 Columns Mode</a></li>
                                        <li><a href="/shop/?type=list">List Mode</a></li></ul></div></li></ul></div></li>


                    {/* <li>
                        <Card title="categories" type="mobile" url="/shop">
                            <ul>
                                <li>
                                    <Card title="Variations 1" type="mobile">
                                        <ul>
                                            {
                                                mainMenu.shop.variation1.map((item, index) => (
                                                    <li key={`shop-${item.title}`}>
                                                        <ALink href={'/' + item.url}>
                                                            {item.title}
                                                            {item.hot ? <span className="tip tip-hot">Hot</span> : ""}
                                                        </ALink>
                                                    </li>
                                                ))
                                            }
                                        </ul>
                                    </Card>
                                </li>
                                <li>
                                    <Card title="Variations 2" type="mobile">
                                        <ul>
                                            {
                                                mainMenu.shop.variation2.map((item, index) => (
                                                    <li key={`shop-${item.title}`}>
                                                        <ALink href={'/' + item.url}>
                                                            {item.title}
                                                            {item.new ? <span className="tip tip-new">New</span> : ""}
                                                        </ALink>
                                                    </li>
                                                ))
                                            }
                                        </ul>
                                    </Card>
                                </li>
                            </ul>
                        </Card>
                    </li> */}

                    <li>
                        <Card title="Products" type="mobile" url="/product/default/beyond-riode-original-t-shirt">
                            <ul>
                                <li>
                                    <Card title="Product Pages" type="mobile">
                                        <ul>
                                            {
                                                mainMenu.product.pages.map((item, index) => (
                                                    <li key={`product-${item.title}`}>
                                                        <ALink href={'/' + item.url}>
                                                            {item.title}
                                                            {item.hot ? <span className="tip tip-hot">Hot</span> : ""}
                                                        </ALink>
                                                    </li>
                                                ))
                                            }
                                        </ul>
                                    </Card>
                                </li>

                                <li>
                                    <Card title="Product Layouts" type="mobile">
                                        <ul>
                                            {
                                                mainMenu.product.layout.map((item, index) => (
                                                    <li key={`product-${item.title}`}>
                                                        <ALink href={'/' + item.url}>
                                                            {item.title}
                                                            {item.new ? <span className="tip tip-new">New</span> : ""}
                                                        </ALink>
                                                    </li>
                                                ))
                                            }
                                        </ul>
                                    </Card>
                                </li>
                            </ul>
                        </Card>
                    </li>

                    <li>
                        <Card title="Pages" type="mobile" url="/pages/about-us">
                            <ul>
                                {
                                    mainMenu.other.map((item, index) => (
                                        <li key={`other-${item.title}`}>
                                            <ALink href={'/' + item.url}>
                                                {item.title}
                                                {item.new ? <span className="tip tip-new">New</span> : ""}
                                            </ALink>
                                        </li>
                                    ))
                                }
                            </ul>
                        </Card>
                    </li>

                    <li>
                        <Card title="Blog" type="mobile" url="/blog/classic">
                            <ul>
                                {
                                    mainMenu.blog.map((item, index) => (
                                        item.subPages ?
                                            <li key={"blog" + item.title}>
                                                <Card title={item.title} url={'/' + item.url} type="mobile">
                                                    <ul>
                                                        {
                                                            item.subPages.map((item, index) => (
                                                                <li key={`blog-${item.title}`}>
                                                                    <ALink href={'/' + item.url}>
                                                                        {item.title}
                                                                    </ALink>
                                                                </li>
                                                            ))
                                                        }
                                                    </ul>
                                                </Card>
                                            </li> :

                                            <li key={"blog" + item.title} className={item.subPages ? "submenu" : ""}>
                                                <ALink href={'/' + item.url}>
                                                    {item.title}
                                                </ALink>
                                            </li>
                                    ))
                                }
                            </ul>
                        </Card>
                    </li>

                    <li>
                        <Card title="elements" type="mobile" url="/elements">
                            <ul>
                                {
                                    mainMenu.element.map((item, index) => (
                                        <li key={`elements-${item.title}`}>
                                            <ALink href={'/' + item.url}>
                                                {item.title}
                                            </ALink>
                                        </li>
                                    ))
                                }
                            </ul>
                        </Card>
                    </li>

                    <li><a href="https://d-themes.com/buynow/riodereact">Buy Riode!</a></li>
                </ul>

                <ul className="mobile-menu mmenu-anim">
                    <li><ALink href={'/pages/account'}>Login</ALink></li>
                    <li><ALink href={'/pages/cart'}>My Cart</ALink></li>
                    <li><ALink href={'/pages/wishlist'}>Wishlist</ALink></li>
                </ul>
            </div>
            {/* <div className="mobile-menu-container scrollable">
                <h5 className="mb-0 border-bottom-2">
                    Menu
                </h5>
                <ul className="mobile-menu mmenu-anim tab-content mb-0">
                    <div className="tab-pane active pb-0" id="tab-1">
                        <li>
                            <a href="#." className="d-flex align-items-center">
                                About <span className="toggle-btn" />
                                <span className="toggle-btn" /></a>
                            <ul>
                                <li>
                                    <a href="#">About Us</a>
                                </li>
                                <li>
                                    <a href="#">Career</a>
                                </li>
                                <li>
                                    <a href="#">Campaign</a>
                                </li>
                            </ul>
                        </li>

                        <li>
                            <a href="#." className="d-flex align-items-center">
                                My Account <span className="toggle-btn" />
                                <span className="toggle-btn" /></a>
                            <ul>
                                <li>
                                    <a href="#">Login</a>
                                </li>
                                <li>
                                    <a href="#">View Cart </a>
                                </li>
                                <li>
                                    <a href="#">My Wishlist </a>
                                </li>
                                <li>
                                    <a href="#">Track My Order </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#." className="d-flex align-items-center">
                                Policy
                                <span className="toggle-btn" /></a>
                            <ul>
                                <li><a href="#.">Privacy Policy</a></li>
                                <li><a href="#.">Cancellation &amp; Returns</a></li>
                                <li><a href="#.">Refund Policy</a></li>
                                <li><a href="#.">Terms &amp; Conditions</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#." className="d-flex align-items-center">
                                Services <span className="toggle-btn" />
                                <span className="toggle-btn" /></a>
                            <ul>
                                <li><a href="#.">Payment Methods</a></li>
                                <li><a href="#.">Shipping</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#." className="d-flex align-items-center">
                                Be a Seller
                            </a>
                        </li>
                        <li>
                            <a href="#." className="d-flex align-items-center">
                                Find Us <span className="toggle-btn" />
                                <span className="toggle-btn" /></a>
                            <ul>
                                <li><a href="#.">Facebook</a></li>
                                <li><a href="contact-us.html">Twitter</a></li>
                                <li><a href="account.html">Instagram</a></li>
                                <li><a href="faq.html">Youtube</a></li>
                            </ul>
                        </li>
                    </div>
                </ul>
                <div className="pb-2 pt-2 side-menu border-top">
                    <h6 className="mb-0"> Office Address </h6>
                    <p className="mb-0 font-weight-normal">House -1150, 4th Floor, Road-9/A, Avenue-11, Mirpur DOHS,
                        Dhaka-1216.
                    </p>
                    <a href="#." className="d-flex align-items-center font-weight-normal">
                        <img src="images/phone.svg" className="mr-1" />
                        09613-826633(9am - 6pm)
                    </a>
                    <a href="#." className="d-flex align-items-center text-lowercase font-weight-normal">
                        <img src="images/email.svg" className="mr-1" />
                        info@futurebazar.com
                    </a>
                </div>
                <div className="sticky-content fix-bottom fixed pt-3 pb-2 side-menu border-top">
                    <div className="d-flex justify-content-center">
                        <a href="#" className="text-center">
                            <img src="images/playstore.svg" width="100px" className="mr-1" />
                        </a>
                        <a href="#" className="text-center">
                            <img src="images/app-store.svg" width="100px" />
                        </a>
                    </div>
                    <div className="text-center">
                        <img src="images/sslcommerz.png" alt="payment" width="90%" />
                        <p className="mb-0 font-12"> © 2020-2021 <a href="#."> b71.com</a>. All Rights Reserved</p>
                    </div>
                </div>
            </div> */}

            {/* <div className="mobile-menu-container scrollable">
                <form action="#" className="input-wrapper" onSubmit={ onSubmitSearchForm }>
                    <input type="text" className="form-control" name="search" autoComplete="off" value={ search } onChange={ onSearchChange }
                        placeholder="Search your keyword..." required />
                    <button className="btn btn-search" type="submit">
                        <i className="d-icon-search"></i>
                    </button>
                </form>

                <ul className="mobile-menu mmenu-anim">
                    <li><ALink href="#" className="menu-title">{t('common:categories')}</ALink></li>
                    {
                        categoryList.map( cat =>
                            <li key={ `mobile-cat-${ cat.url_key }` }>
                                <ALink className="category-lable-first" href={ { pathname: "/s", query: { category: cat.url_key } } }>
                                    {
                                        cat.icon ? <div className="mr-2">
                                            <Image
                                                src={ process.env.NEXT_PUBLIC_ASSET_URI + "/" + cat?.icon }
                                                alt="Picture of the author"
                                                placeholder="blur"
                                                width={30}
                                                height={30}
                                                quality={90}
                                                blurDataURL="/images/categories/daily-needs.svg"
                                            />
                                        </div> : <i className="d-icon-shoppingbag"></i>
                                    }
                                    { cat.label }
                                </ALink>
                            </li>
                        ) }
                    <li><ALink href="#" className="menu-title">Today Coupon Deals</ALink>
                    </li>
                    <li>
                        <ALink href={ { pathname: '/s', query: { category: 'backpacks-and-fashion-bags' } } }>
                            <i className="d-icon-card"></i>Backpacks &amp; Fashion bags
                            </ALink>
                    </li>
                    <li>
                        <ALink href="#">
                            <i className="d-icon-card"></i>Daily Deals
                            </ALink>
                    </li>
                </ul>
            </div> */}
        </div>
    )
}

function mapStateToProps(state) {
    return {
        categoryList: state.category.data
    }
}

export default connect(mapStateToProps, {})(MobileMenu);