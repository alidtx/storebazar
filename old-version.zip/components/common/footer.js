import { useRouter } from 'next/router';
import { useQuery  } from '@apollo/client';
import { CMS_CONTENT_QUERY } from '../../server/queries';

function Footer() {
    // Router
    const router = useRouter();

    // GraphQL Queries
    const { loading, error, data } = useQuery(CMS_CONTENT_QUERY, {
        variables: { 
            languageId: router.locale === 'en' ? 1 : 2, 
            slug: 'footer' 
        },
    });

    const content = data && data.cmsDetails && data.cmsDetails?.cmsDetails[0]?.content ? data.cmsDetails?.cmsDetails[0]?.content : '';

    return (
        <footer className="footer appear-animate fadeIn appear-animation-visible" style={{animationDuration: '1.2s'}}>
            <div dangerouslySetInnerHTML={{ __html: content }} />
        </footer>
    )
}

export default Footer;
