import React from 'react';
// import Reveal from "react-awesome-reveal";
// import { LazyLoadImage } from 'react-lazy-load-image-component';
import Image from "next/image"
import ALink from '../features/custom-link';
// import SidebarMenu from '../partials/sidebar-menu';
import OwlCarousel from '../features/owl-carousel';
import { introSlider, introCategorySlider } from '../../utils/data/carousel';
import {isUnderCampaign} from '../../utils';
import SidebarMenuTwo from '../partials/sidebar-menu-two';

function IntroSection(props) {
    // Props
    const {sliders, campaigns, context} = props;

    // Active campaigns, filtered by start-end time
    const filteredCampaigns = campaigns.filter((campaignItem) => isUnderCampaign(campaignItem));

    // Sorted banners by position
    const banners = sliders.Banner && sliders.Banner.length>0 ? sliders.Banner : null;
    const sortedBanners = banners && banners.sort((a, b) => a.position - b.position);


    return (
        <div className="intro-section appear-animate fadeIn appear-animation-visible home-intro-section">
            <div className="container-fluid">
                <div className="row">
                    {!context ? (
                        <div className="col-xl-3 col-lg-3 col-md-12 height-x2 category-list d-lg-block d-none top-0">
                            {/* <SidebarMenu /> */}
                            <SidebarMenuTwo/>
                        </div>
                    ) : (
                        ""
                    )}

                    <div
                        className={
                            !context
                                ? "col-xl-9 col-lg-9 col-md-12"
                                : "col-xl-12 col-lg-12 col-md-12"
                        }
                    >
                        <OwlCarousel
                            adClass="intro-slider owl-theme owl-dot-inner animation-slider"
                            options={introSlider}
                        >
                            {sortedBanners
                                ? sortedBanners.map((banner, index) => (
                                      <div
                                          className="banner banner-fixed"
                                          key={"banner-" + banner?.id}
                                      >
                                          <ALink href={banner?.redirect_url}>
                                              <figure>
                                                {/* <div className='home-banner'> */}
                                                    <Image
                                                        alt='Mountains'
                                                        src={
                                                            process.env
                                                                .NEXT_PUBLIC_ASSET_URI +
                                                            "/" +
                                                            banner.link
                                                        }
                                                        width={1640}
                                                        height={624}
                                                        layout='responsive'
                                                        objectFit='cover'
                                                        quality={75}
                                                    />
                                                {/* </div> */}
                                                    {/* <Image
                                                        src={
                                                            process.env
                                                                .NEXT_PUBLIC_ASSET_URI +
                                                            "/" +
                                                            banner.link
                                                        }
                                                        alt="Intro Slider"
                                                        width="100%" height={460} layout="fill"
                                                        objectFit="cover"
                                                        // width={480}
                                                        // height={460}
                                                        // layout="fill" 
                                                        quality={60}
                                                    /> */}
                                                  {/* <LazyLoadImage
                                                      src={
                                                          process.env
                                                              .NEXT_PUBLIC_ASSET_URI +
                                                          "/" +
                                                          banner.link
                                                      }
                                                      alt="Intro Slider"
                                                      effect="opacity"
                                                      width="auto"
                                                      // height={ 460 }
                                                  /> */}
                                              </figure>
                                          </ALink>
                                      </div>
                                  ))
                                : ""}
                        </OwlCarousel>

                        <OwlCarousel
                            adClass="intro-slider owl-theme owl-dot-inner animation-slider banner-area-custom"
                            options={introCategorySlider}
                        >
                            {/* <div className="row mt-2 px-2">
                                {
                                    campaigns?.length ? campaigns.map((campaign, index) => <div className="col-lg-3 col-md-3 col-sm-3 height-x1" key={"campaign4-" + index}>
                                        <div className="category category-new category-absolute overlay-dark category-banner banner-radius">
                                            <ALink href={`/campaign/${campaign.id}`}>
                                                <figure className="category-media">
                                                    <Image 
                                                        layout="responsive" 
                                                        src={process.env.NEXT_PUBLIC_ASSET_URI + "/" + campaign.thumbnail} 
                                                        alt="banner" 
                                                        width={480} 
                                                        height={328} 
                                                        quality={10}/>
                                                </figure>
                                                <div className="category-content y-50 appear-animate fadeIn appear-animation-visible"
                                                    style={{ animationDuration: '1.2s' }}>
                                                </div>
                                            </ALink>    
                                        </div>
                                    </div>) : ''
                                }
                            </div> */}

                            {filteredCampaigns?.length
                                ? filteredCampaigns.map((campaign, index) => {
                                      return (
                                          <div
                                              className="mt-2 px-10-px height-x1"
                                              key={"campaign54-" + index}
                                          >
                                              <div className="category category-new category-absolute overlay-dark category-banner banner-radius">
                                                  <ALink
                                                      href={`/campaign/${campaign.id}`}
                                                  >
                                                      <figure className="category-media">
                                                            {/* <div>
                                                                <Image
                                                                        layout="responsive"
                                                                        src={
                                                                            process.env
                                                                                .NEXT_PUBLIC_ASSET_URI +
                                                                            "/" +
                                                                            campaign.thumbnail
                                                                        }
                                                                        alt="campaign_image"
                                                                        width={480}
                                                                        height={328}
                                                                        quality={10}
                                                                />
                                                            </div> */}

                                                            <img
                                                                src={
                                                                    process.env
                                                                        .NEXT_PUBLIC_ASSET_URI +
                                                                    "/" +
                                                                    campaign.thumbnail
                                                                }
                                                                alt="campaign_image"
                                                                width={480}
                                                                height={328}
                                                            />
                                                      </figure>
                                                      <div
                                                          className="category-content y-50 appear-animate fadeIn appear-animation-visible"
                                                          style={{
                                                              animationDuration:
                                                                  "1.2s",
                                                          }}
                                                      ></div>
                                                  </ALink>
                                              </div>
                                          </div>
                                      );
                                  })
                                : ""}
                        </OwlCarousel>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default React.memo( IntroSection );