import React from 'react';
import Reveal from 'react-awesome-reveal';
import { useRouter } from 'next/router';
import OwlCarousel from '../features/owl-carousel';
import ProductTwo from '../product/product-two';
import CampaignProductItem from '../product/campaign-product-item';
import ALink from '../features/custom-link';
import { productSlider } from '../../utils/data/carousel';
import { fadeIn } from '../../utils/data/keyframes';
import useTranslation from "next-translate/useTranslation";


function NewCollection(props) {
    // Props
    const { 
        products, 
        productTitle, 
        loading, 
        context, 
        campaignId, 
        addClass,
        view,
        zIndex_1
    } = props;

    // Router
    const router = useRouter();

    // Others
    let {t} = useTranslation();

    return (
        <Reveal keyframes={ fadeIn } delay={ 300 } duration={ 1200 } triggerOnce>
            <section className={`mt-0 mb-5 card-product-content pt-0 pb-0 ${addClass}  ${router.pathname !== '/' ? " bg-white" : ''}`}>
                <h2 className={`title title-line title-underline with-link `}><span>{productTitle}</span> {/* ${zIndex_1 ? "zIndex_1" : ''} */}
                    <ALink href={ campaignId ? { pathname: `/campaign/${campaignId}` } : { pathname: '/s', query: view ? {view: view} : {"view-all": 'true'}} }
                    className="font-weight-bold">{t('common:see_all')} <i className="d-icon-angle-right"></i></ALink>
                </h2>
                
                {
                    loading ?
                        <OwlCarousel adClass="owl-theme owl-nav-full" options={ productSlider }>
                            {
                                [ 1, 2, 3, 4, 5 ].map( ( item ) =>
                                    <div className="product-loading-overlay" key={ 'new-skel-' + item }></div>
                                )
                            }
                        </OwlCarousel>
                        :
                        <OwlCarousel adClass={`owl-theme owl-nav-full `} options={ productSlider }> {/* ${zIndex_1 ? "zIndex_1" : ''} */}
                            {
                                products && products.map( ( item, index ) =>
                                context === 'campaign' ? (
                                    <CampaignProductItem
                                        product={
                                            item?.productVariation?.productDetails
                                        }
                                        adClass=""
                                        imageWidth={350}
                                        imageHight={350}
                                        campaignDiscoutPrice={item?.discount_price}
                                        previousPrice={item?.productVariation?.price}
                                        selectedVariant={item?.productVariation?.id}
                                    />
                                ) : (
                                    <ProductTwo
                                        newLabel={ false }
                                        product={item}
                                        adClass="text-left"
                                        key={ `new-product ${ index }` }
                                    />
                                ))
                            }
                        </OwlCarousel>
                }
            </section>
        </Reveal>
    )
}

export default React.memo( NewCollection );
