import { useEffect, useLayoutEffect, useState } from 'react';
import { connect } from 'react-redux';
import { ToastContainer } from 'react-toastify';
import { useRouter } from 'next/router';
import Head from "next/head"

import 'react-toastify/dist/ReactToastify.min.css';
// import 'react-image-lightbox/style.css';
// import 'react-input-range/lib/css/index.css';

import ALink from '../features/custom-link';

import Header from '../common/header';
import StickyFooter from '../common/sticky-footer';
import MobileMenu from '../common/mobile-menu';

import { modalActions } from '../../store/modal';
// import Script from 'next/script';

import { showScrollTopHandler, scrollTopHandler, stickyHeaderHandler, 
    stickyFooterHandler, resizeHandler } from '../../utils';
// import { dateFormate } from '../../utils/helpers';


function Layout( { children, closeLoginModal, userInfo } ) {
    const router = useRouter();
    const [usarInfo, setUseInfo] = useState();
    const [count, setCount] = useState(1);
    const child0 = children[0];
    const props = child0 && child0.props ? child0.props : null;
    const meta = props && props.meta ? props.meta : null;

    useLayoutEffect( () => {
        document.querySelector( 'body' ) && document.querySelector( 'body' ).classList.remove( 'loaded' );
    }, [ router.pathname ] )

    useEffect( () => {
        window.addEventListener( 'scroll', showScrollTopHandler, true );
        window.addEventListener( 'scroll', stickyHeaderHandler, true );
        window.addEventListener( 'scroll', stickyFooterHandler, true );
        window.addEventListener( 'resize', stickyHeaderHandler );
        window.addEventListener( 'resize', stickyFooterHandler );
        window.addEventListener( 'resize', resizeHandler );

        return () => {
            window.removeEventListener( 'scroll', showScrollTopHandler, true );
            window.removeEventListener( 'scroll', stickyHeaderHandler, true );
            window.removeEventListener( 'scroll', stickyFooterHandler, true );
            window.removeEventListener( 'resize', stickyHeaderHandler );
            window.removeEventListener( 'resize', stickyFooterHandler );
            window.removeEventListener( 'resize', resizeHandler );
        }
    }, [] );

    useEffect( () => {
        closeLoginModal();

        let bodyClasses = [ ...document.querySelector( "body" ).classList ];
        for ( let i = 0; i < bodyClasses.length; i++ ) {
            document.querySelector( 'body' ).classList.remove( bodyClasses[ i ] );
        }

        setTimeout( () => {
            document.querySelector( 'body' ).classList.add( 'loaded' );
        }, 50 );
    }, [ router.pathname ] );

    useEffect(() => {
        if (userInfo) {
            // setTimeout(() => {
                let setUser = {
                    mobile: userInfo.mobile,
                    email: userInfo.email,
                    name: userInfo.customer.name
                };
    
                if (count == 1 && window?.ibotApp) {
                    setCount(2);
                    window.ibotApp(JSON.stringify(setUser));
                };
            // }, 2000)
        }
    }, [userInfo, count])

    return (
        <>
            <Head>
                <title> {meta?.title ? meta.title : 'Be Smart Shop Smart'} </title>
            </Head>

            <div className={"page-wrapper " + router.pathname === '/' ? bg-white : ''}>
                <Header />

                { children }

                <StickyFooter />
            </div>

            <ALink id="scroll-top" href="#" title="Top" role="button" className="scroll-top" onClick={ () => scrollTopHandler( false ) }><i className="d-icon-arrow-up"></i></ALink>

            <MobileMenu />

            <ToastContainer
                autoClose={ 3000 }
                duration={ 300 }
                newestOnTo={ true }
                className="toast-container"
                position="bottom-left"
                closeButton={ false }
                hideProgressBar={ true }
                newestOnTop={ true }
            />

{/* + (Math.floor(Math.random() * 100)) */}
            {/* <Script 
                src={"https://finbot.publicdemo.xyz/b71/bundle.min.js?v=" + new Date().getTime() }
                ibot_key="ssl-eb580e4b-ce13-46ff"
                data_user= {usarInfo} //{usarInfo} //'{"mobile":"07113212","email":"nasim@outlook.com","name":"Test Bot 44"}'
                id="ibot_id"
                // strategy="lazyOnload" 
            /> */}
            
        </>
    )
}

function mapStateToProps( state ) {
    return {
        userInfo: state.user.userInfo
    }
}

export default connect( mapStateToProps, {closeLoginModal: modalActions.closeLoginModal})( Layout );