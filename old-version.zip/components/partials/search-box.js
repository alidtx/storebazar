import React, { Fragment, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Image from 'next/image';
import { useMutation } from "@apollo/client";
import ALink from '../features/custom-link';
import { SEARCH_SUGGESTION } from "../../server/queries";
import { canShowSpecialPrice } from "../../utils";
import OutsideClickHandler from 'react-outside-click-handler';



const SearchBox = () => {
    // States
    const [searchResult, setSearchResult] = useState();
    const [ search, setSearch ] = useState( "" );
    const [ timer, setTimer ] = useState( 'null' );

    // Router
    const router = useRouter();
    
    // Graphql Queries
    const [ searchProducts ] = useMutation( SEARCH_SUGGESTION, {
        onError: ({ graphQLErrors, networkError, operation, forward }) => {
            if (graphQLErrors?.length) {
                
            }
            setSearchResult(null);
        }
    });


    useEffect( () => {
        document.querySelector( "body" ).addEventListener( "click", onBodyClick );

        return ( () => {
            document.querySelector( "body" ).removeEventListener( "click", onBodyClick );
        } )
    }, [] );

    useEffect( () => {
        setSearch( "" );
        setSearchResult(null);
    }, [ router.query ] );

    useEffect( () => {
        if ( search.length > 2 ) {
            if ( timer ) clearTimeout( timer );
            let timerId = setTimeout( () => {
                getSearchData()
            }, 500 );

            setTimer( timerId );
        } else {
            setSearchResult(null);
        }
    }, [ search ] );

    useEffect( () => {
        document.querySelector( '.header-search.show-results' ) && document.querySelector( '.header-search.show-results' ).classList.remove( 'show-results' );
    }, [ router.pathname ]);

    const getSearchData = async () => {
        let res = await searchProducts( { variables: { searchQuery: search } } );

        if (res) {
            let masterData = res?.data?.suggestion;
            let parsedAdditionalData = masterData.additionals ? JSON.parse(masterData.additionals) : [];
            // Get unique categories filtered by category id
            let uniqueCategoryData = [...new Map(parsedAdditionalData.map(item => [item?._source?.categoryDetails?.categoryDetailInformation?.id, item])).values()];
            
            let content = {
                category: masterData?.additionals ? uniqueCategoryData : [],
                product: masterData?.additionals ? parsedAdditionalData : [],
                suggestion: masterData?.suggestion ? JSON.parse(masterData.suggestion) : [],
            }

            // console.log({content});
            

            setSearchResult(content);

            setTimer( null );
        }
    }

    function onSearchClick( e ) {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.parentNode.classList.toggle( 'show' );
    }

    function onBodyClick( e ) {
        if ( e.target.closest( '.header-search' ) ) return e.target.closest( '.header-search' ).classList.contains( 'show-results' ) || e.target.closest( '.header-search' ).classList.add( 'show-results' );

        document.querySelector( '.header-search.show' ) && document.querySelector( '.header-search.show' ).classList.remove( 'show' );
        document.querySelector( '.header-search.show-results' ) && document.querySelector( '.header-search.show-results' ).classList.remove( 'show-results' );
    }

    function onSearchChange( e ) {
        setSearch( e.target.value );
    }

    const handleKeyDownSearch = (event) => {
        if (event.key === 'Enter' ) {
            let value = event.target.value;
            if (value?.length > 2 ) {
                console.log();
                router.push(`/s/?search=${value}`);

                setTimeout(() => {
                    setSearchResult(null);
                }, 1000)
            }
        }
    }

    function onSubmitSearchForm( e ) {
        e.preventDefault();

        if (search) {
            // router.push( {
            //     pathname: '/s',
            //     query: {
            //         search: search
            //     }
            // });
            router.push(`/s/?search=${search}`);

            setTimeout(() => {
                setSearchResult(null);
            }, 1000)

            // getSearchData()
        }
    }

    // Render popular suggestions list UI
    const renderPopularSuggestionsUI = () => {
        if(searchResult?.suggestion && searchResult?.suggestion?.length>0) {
            return (
                <Fragment>
                    <li className="snize-label snize-removable">
                        Popular suggestions
                    </li>
                    {searchResult?.suggestion.map((data, index) => (
                        <li
                            className="snize-suggestion snize-ac-odd snize-removable"
                            key={"suggestion-" + data.suggestion}
                        >
                            <ALink
                                href={`/s/?search=${data.suggestion}`}
                                className="snize-view-link"
                                data-no-instant="true"
                            >
                                {data.suggestion}
                            </ALink>
                        </li>
                    ))}
                </Fragment>
            );
        }
        else {
            return null;
        }
    }

    // Render categories suggestions list UI
    const renderCategoriesUI = () => {
        if(searchResult?.category && searchResult?.category?.length>0) {
            return (
                <Fragment>
                    <li className="snize-label snize-removable">Categories</li>
                    {searchResult?.category.map((cat, index) => {
                        let categoryDetails = cat?._source?.categoryDetails;
                        let categoryDetailInformation = categoryDetails?.categoryDetailInformation;
                        let category_id = categoryDetailInformation?.id;
                        let url_key = categoryDetailInformation?.url_key;
                        let category_name = categoryDetailInformation?.category_detail ? categoryDetailInformation?.category_detail[0]?.name : null;

                        if (category_id && url_key && category_name) {
                            return (
                                <li
                                    className="snize-category snize-ac-odd snize-removable"
                                    key={"cater--" + category_id}
                                >
                                    <ALink
                                        href={`/category/${url_key}/`}
                                        className="snize-view-link"
                                        data-no-instant="true"
                                    >
                                        {category_name}
                                    </ALink>
                                </li>
                            );
                        } else {
                            return null;
                        }
                    })}
                </Fragment>
            );
        }
        else {
            return null;
        }
    }

    // Render products suggestions list UI
    const renderProductsUI = () => {
        if(searchResult?.product && searchResult?.product?.length>0) {
            return (
                <Fragment>
                    <li className="snize-label snize-removable">Products</li>
                    {searchResult?.product.map((pro, index) => {
                        let productItem = pro?._source;
                        let productVariation = productItem?.productVariation;
                        let productVariationFirstItem = productVariation && productVariation.length>0 ? productVariation[0] : null;
                        let productDetail = productItem?.productDetail;
                        let productDetailFirstItem = productDetail && productDetail.length>0 ? productDetail[0] : null;

                        {/* Set Data to show in the UI */}
                        let image_path = productVariationFirstItem?.productVariationImage?.length ? productVariationFirstItem?.productVariationImage[0]?.image_path : '';
                        let product_name = productDetailFirstItem ? productDetailFirstItem?.name : null;
                        let short_description = productDetailFirstItem ? productDetailFirstItem?.short_description : null;
                        let price = productVariationFirstItem ? productVariationFirstItem.price : null;
                        let quantity = productVariationFirstItem ? productVariationFirstItem.qty : null;

                        return (
                            <li
                                className="snize-ac-odd snize-product snize-removable"
                                id="snize-ac-product-812"
                                key={"sea-product-" + index}
                            >
                                <a
                                    href={`/product/${productItem.url_key}`}
                                    className="snize-item clearfix"
                                    draggable="false"
                                >
                                    <span className="snize-thumbnail">
                                        <Image
                                            src={
                                                image_path
                                                    ? process.env
                                                          .NEXT_PUBLIC_ASSET_URI +
                                                      "/" +
                                                      image_path
                                                    : "/images/b71.png"
                                            }
                                            className="snize-item-image"
                                            height={70}
                                            width={70}
                                            quality={10}
                                            alt=""
                                            border="0"
                                        />
                                    </span>
                                    <span className="snize-overhidden">
                                        <span className="snize-title">
                                            {product_name}
                                        </span>
                                        <span className="snize-description">
                                            {short_description}
                                        </span>
                                        <div className="snize-price-list">
                                            <span className="snize-price product-price money ">
                                                BDT {
                                                    showProductPrice(productItem, productVariationFirstItem) ? <>
                                                        <ins className="new-price">{showProductPrice(productItem, productVariationFirstItem)}</ins>
                                                        <del className="old-price">{price}</del>
                                                    </> : <>
                                                        <ins className="new-price">
                                                            {price}
                                                        </ins>
                                                    </>
                                                }  
                                            </span>
                                        </div>
                                        <span
                                            className="snize-in-stock"
                                            style={
                                                quantity < 1
                                                    ? { color: "red" }
                                                    : {}
                                            }
                                        >
                                            {quantity > 1
                                                ? "In Stock"
                                                : "Out of Stock"}
                                        </span>
                                    </span>
                                </a>
                            </li>
                        );
                    })}
                </Fragment>
            );
        }
        else {
            return null;
        }
    }

    const showProductPrice = (product, firstVarient) => {
        // console.log("product ==", product);
        return canShowSpecialPrice(firstVarient);
    }

    return (
        <div className="header-search hs-simple">
            <a
                href="#"
                className="search-toggle"
                role="button"
                onClick={onSearchClick}
            >
                <i className="icon-search-3"></i>
            </a>

            <form
                action="#"
                method="get"
                onSubmit={onSubmitSearchForm}
                className="input-wrapper"
            >
                <input
                    type="text"
                    id="js-search-input-field"
                    className="form-control"
                    name="search"
                    autoComplete="off"
                    value={search}
                    onChange={onSearchChange}
                    onKeyDown={handleKeyDownSearch}
                    placeholder="পণ্য অনুসন্ধান করুন ..."
                />

                <button className="btn btn-search" type="submit">
                    <i className="d-icon-search"></i>
                </button>
            </form>

            {searchResult ? (
                <OutsideClickHandler onOutsideClick={() => {
                    setSearchResult(); setSearch(''); setTimer('null')
                  }}>
                    <div className="snize-ac-results">
                        <div
                            className="snize-dropdown-arrow"
                            style={{ right: "auto", left: "30px" }}
                        >
                            <div className="snize-arrow-outer"></div>
                            <div className="snize-arrow-inner snize-arrow-inner-label"></div>
                        </div>

                        <ul>
                            {renderPopularSuggestionsUI()}
                            {renderCategoriesUI()}
                            {renderProductsUI()}

                            {/* <li className="snize-view-all-link snize-ac-even snize-removable">
                                <span>View all 241 items</span>
                                <i className="snize-ac-results-arrow"></i>
                            </li> */}
                        </ul>
                    </div>
                </OutsideClickHandler>
            ) : (
                ""
            )}
        </div>
    );
}

export default SearchBox;
