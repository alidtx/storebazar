import Image from "next/image";
import { connect } from 'react-redux';
import ALink from '../features/custom-link';

function SidebarMenuTwo({ categoryList, handelCollepes }) {

    // console.log("categoryList =========", categoryList);
    
    return (
        <div className="lzd-site-nav-menu-dropdown"  data-config="{}" style={{ visibility: "inherit" }}>
            <ul className="lzd-site-menu-sub Level_1" data-spm="cate_1">
                {
                    categoryList?.length ? categoryList.map(category => <li className="lzd-site-menu-sub-item" 
                        data-cate="cate_1_1" key={"category-menu-" + category.id}>
                            <ALink href={`/category/${category.url_key}`} className="active-label"
                                onClick={() => handelCollepes()}>
                                {
                                    category.icon ? <div className="mr-2">
                                        <Image className="cat-image-custom"
                                            src={ process.env.NEXT_PUBLIC_ASSET_URI + "/" + category?.icon }
                                            alt="Picture of the author"
                                            width={24}
                                            height={25}
                                            quality={50}
                                        />
                                    </div> : <i className={"d-icon-shoppingbag mr-4"}></i>
                                }
                                <span>{category?.label}</span>
                                {category?.children?.length ?  <i className={"d-icon-angle-right"}></i>  : ''}
                             
                            </ALink>

                            {
                                category?.children?.length ? <ul className="lzd-site-menu-grand Level_2 lzd-site-menu-sub-active" data-spm="cate_1_1">
                                    {
                                        category.children.map(subCat => <li className="lzd-site-menu-grand-item"
                                        key={"subcategory-menu-" + subCat.id}>
                                            <ALink href={`/category/${subCat.url_key}`} onClick={() => handelCollepes()}>
                                                <span>{subCat?.label}   {subCat?.children?.length ? <i className={"d-icon-angle-right"}></i> : "" } </span> 
                                            </ALink>

                                            {
                                                subCat?.children?.length ? <ul className="lzd-site-menu-grand Level_3" 
                                                    data-spm="cate_1_1">
                                                    {
                                                        subCat.children.map(item => <li className="lzd-site-menu-grand-last-item"
                                                            key={"trtsub-23" + item.id}>
                                                                {/* href={ { pathname: '/s', query: { category: item.url_key } } } */}
                                                            <ALink href={`/category/${item.url_key}`} onClick={() => handelCollepes()}>
                                                                <span>{ item?.label }</span>
                                                            </ALink>
                                                        </li>)
                                                    }
                                                </ul> : ''
                                            }
                                        </li>)
                                    }
                                </ul> : ''
                            }
                        </li>) : ''
                }
            </ul>

            {/* </ul> */}
        </div>
    )
}


function mapStateToProps( state ) {
    return {
        categoryList: state.category.data
    }
}

export default connect( mapStateToProps, { } )( SidebarMenuTwo );