// Styles imported inside style.scss file
// @import "~/node_modules/placeholder-loading/src/scss/placeholder-loading";

const LoadingPlaceholder = () => {
    return (
        <div>
            <div className="ph-item">
                <div className="ph-col-12">
                    <div className="ph-row">
                        <div className="ph-col-2 big"></div>
                        <div className="ph-col-6 empty"></div>
                        <div className="ph-col-4 big"></div>
                        <div className="ph-col-4 big"></div>
                        <div className="ph-col-4 empty"></div>
                        <div className="ph-col-4 big"></div>
                        <div className="ph-col-4 big"></div>
                        <div className="ph-col-8 empty"></div>
                    </div>
                </div>
                <div className="ph-col-4">
                    <div className="ph-picture h-450-p"></div>
                </div>
                <div className="ph-col-8">
                    <div className="ph-row">
                        <div className="ph-picture h-280-p"></div>
                    </div>
                    <div className="ph-row">
                        <div className="ph-col-12 h-162-p"></div>
                    </div>
                </div>
                <div className="ph-col-12">
                    <div className="ph-picture h-200-p"></div>
                </div>
                <div className="ph-col-12">
                    <div className="ph-picture h-200-p"></div>
                </div>
                <div className="ph-col-12">
                    <div className="ph-picture h-200-p"></div>
                </div>
            </div>
        </div>
    );
}

export default LoadingPlaceholder;
